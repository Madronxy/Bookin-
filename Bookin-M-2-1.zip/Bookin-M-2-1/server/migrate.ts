import { drizzle } from 'drizzle-orm/neon-serverless';
import { migrate } from 'drizzle-orm/neon-serverless/migrator';
import { Pool } from '@neondatabase/serverless';
import ws from 'ws';
import { neonConfig } from '@neondatabase/serverless';

neonConfig.webSocketConstructor = ws;

async function main() {
  const connectionString = process.env.DATABASE_URL;
  
  if (!connectionString) {
    console.error('DATABASE_URL not found');
    process.exit(1);
  }

  console.log('Connecting to database...');
  const pool = new Pool({ connectionString });
  const db = drizzle({ client: pool });

  console.log('Creating tables...');
  
  // Create tables using raw SQL
  await pool.query(`
    CREATE TABLE IF NOT EXISTS "sessions" (
      "sid" varchar PRIMARY KEY,
      "sess" jsonb NOT NULL,
      "expire" timestamp NOT NULL
    );
  `);
  
  await pool.query(`CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "sessions" ("expire");`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS "users" (
      "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
      "email" varchar UNIQUE,
      "first_name" varchar,
      "last_name" varchar,
      "profile_image_url" varchar,
      "created_at" timestamp DEFAULT now(),
      "updated_at" timestamp DEFAULT now()
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS "businesses" (
      "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      "owner_id" varchar NOT NULL REFERENCES "users"("id"),
      "name" varchar NOT NULL,
      "logo_url" varchar,
      "email" varchar,
      "phone" varchar,
      "address" text,
      "description" text,
      "website" varchar,
      "business_hours" jsonb,
      "subscription_plan" varchar NOT NULL DEFAULT 'free',
      "join_date" timestamp DEFAULT now(),
      "booking_qr_url" varchar,
      "whatsapp_qr_url" varchar,
      "whatsapp_number" varchar,
      "whatsapp_api_key" varchar,
      "n8n_webhook_url" varchar,
      "created_at" timestamp DEFAULT now(),
      "updated_at" timestamp DEFAULT now()
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS "staff" (
      "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      "business_id" uuid NOT NULL REFERENCES "businesses"("id"),
      "user_id" varchar REFERENCES "users"("id"),
      "name" varchar NOT NULL,
      "email" varchar,
      "role" varchar NOT NULL,
      "specialties" text[],
      "working_hours" jsonb,
      "is_active" boolean DEFAULT true,
      "created_at" timestamp DEFAULT now(),
      "updated_at" timestamp DEFAULT now()
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS "services" (
      "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      "business_id" uuid NOT NULL REFERENCES "businesses"("id"),
      "name" varchar NOT NULL,
      "description" text,
      "price" decimal(10, 2) NOT NULL,
      "duration" integer NOT NULL,
      "is_active" boolean DEFAULT true,
      "created_at" timestamp DEFAULT now(),
      "updated_at" timestamp DEFAULT now()
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS "clients" (
      "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      "business_id" uuid NOT NULL REFERENCES "businesses"("id"),
      "name" varchar NOT NULL,
      "phone" varchar,
      "email" varchar,
      "tags" text[],
      "notes" text,
      "total_visits" integer DEFAULT 0,
      "last_booking" timestamp,
      "created_at" timestamp DEFAULT now(),
      "updated_at" timestamp DEFAULT now()
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS "bookings" (
      "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      "business_id" uuid NOT NULL REFERENCES "businesses"("id"),
      "client_id" uuid NOT NULL REFERENCES "clients"("id"),
      "service_id" uuid REFERENCES "services"("id"),
      "staff_id" uuid REFERENCES "staff"("id"),
      "date" timestamp NOT NULL,
      "status" varchar NOT NULL DEFAULT 'pending',
      "notes" text,
      "source" varchar DEFAULT 'dashboard',
      "created_at" timestamp DEFAULT now(),
      "updated_at" timestamp DEFAULT now()
    );
  `);

  console.log('Tables created successfully!');
  await pool.end();
  process.exit(0);
}

main().catch((err) => {
  console.error('Migration failed:', err);
  process.exit(1);
});
