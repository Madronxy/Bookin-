import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

// Build connection string from individual PG variables if available, fallback to DATABASE_URL
const connectionString = process.env.PGHOST 
  ? `postgresql://${process.env.PGUSER}:${process.env.PGPASSWORD}@${process.env.PGHOST}:${process.env.PGPORT}/${process.env.PGDATABASE}?sslmode=require`
  : process.env.DATABASE_URL;

let pool: Pool | null = null;
let db: ReturnType<typeof drizzle> | null = null;

if (!connectionString) {
  console.warn('⚠️  DATABASE_URL not found. Database features will be unavailable.');
} else {
  pool = new Pool({ connectionString });
  db = drizzle({ client: pool, schema });
}

export { pool, db };