import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from "ws";

neonConfig.webSocketConstructor = ws;

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

async function initializeDatabase() {
  const connectionString = process.env.PGHOST 
    ? `postgresql://${process.env.PGUSER}:${process.env.PGPASSWORD}@${process.env.PGHOST}:${process.env.PGPORT}/${process.env.PGDATABASE}?sslmode=require`
    : process.env.DATABASE_URL;

  if (!connectionString) {
    log('⚠️  No DATABASE_URL found. Using in-memory storage.');
    return;
  }

  try {
    log('Initializing database tables...');
    const pool = new Pool({ connectionString });

    // Create tables if they don't exist
    await pool.query(`
      CREATE TABLE IF NOT EXISTS "sessions" (
        "sid" varchar PRIMARY KEY,
        "sess" jsonb NOT NULL,
        "expire" timestamp NOT NULL
      );
    `);
    
    await pool.query(`CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "sessions" ("expire");`);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS "users" (
        "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
        "email" varchar UNIQUE,
        "first_name" varchar,
        "last_name" varchar,
        "profile_image_url" varchar,
        "created_at" timestamp DEFAULT now(),
        "updated_at" timestamp DEFAULT now()
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS "businesses" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "owner_id" varchar NOT NULL REFERENCES "users"("id"),
        "name" varchar NOT NULL,
        "logo_url" varchar,
        "email" varchar,
        "phone" varchar,
        "address" text,
        "description" text,
        "website" varchar,
        "business_hours" jsonb,
        "subscription_plan" varchar NOT NULL DEFAULT 'free',
        "join_date" timestamp DEFAULT now(),
        "booking_qr_url" varchar,
        "whatsapp_qr_url" varchar,
        "whatsapp_number" varchar,
        "whatsapp_api_key" varchar,
        "n8n_webhook_url" varchar,
        "created_at" timestamp DEFAULT now(),
        "updated_at" timestamp DEFAULT now()
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS "staff" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "business_id" uuid NOT NULL REFERENCES "businesses"("id"),
        "user_id" varchar REFERENCES "users"("id"),
        "name" varchar NOT NULL,
        "email" varchar,
        "role" varchar NOT NULL,
        "specialties" text[],
        "working_hours" jsonb,
        "is_active" boolean DEFAULT true,
        "created_at" timestamp DEFAULT now(),
        "updated_at" timestamp DEFAULT now()
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS "services" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "business_id" uuid NOT NULL REFERENCES "businesses"("id"),
        "name" varchar NOT NULL,
        "description" text,
        "price" decimal(10, 2) NOT NULL,
        "duration" integer NOT NULL,
        "is_active" boolean DEFAULT true,
        "created_at" timestamp DEFAULT now(),
        "updated_at" timestamp DEFAULT now()
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS "clients" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "business_id" uuid NOT NULL REFERENCES "businesses"("id"),
        "name" varchar NOT NULL,
        "phone" varchar,
        "email" varchar,
        "tags" text[],
        "notes" text,
        "total_visits" integer DEFAULT 0,
        "last_booking" timestamp,
        "created_at" timestamp DEFAULT now(),
        "updated_at" timestamp DEFAULT now()
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS "bookings" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "business_id" uuid NOT NULL REFERENCES "businesses"("id"),
        "client_id" uuid NOT NULL REFERENCES "clients"("id"),
        "service_id" uuid REFERENCES "services"("id"),
        "staff_id" uuid REFERENCES "staff"("id"),
        "date" timestamp NOT NULL,
        "status" varchar NOT NULL DEFAULT 'pending',
        "notes" text,
        "source" varchar DEFAULT 'dashboard',
        "created_at" timestamp DEFAULT now(),
        "updated_at" timestamp DEFAULT now()
      );
    `);

    await pool.end();
    log('✓ Database tables initialized successfully');
  } catch (error) {
    log(`⚠️  Database initialization failed: ${error}. Using in-memory storage.`);
  }
}

(async () => {
  await initializeDatabase();
  
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
