import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { setupWebSocket, broadcastNewBooking, broadcastStatsUpdate } from "./websocket";
import { handlePaystackWebhook, verifyPaystackSignature } from "./paystack";
import {
  insertBusinessSchema,
  insertStaffSchema,
  insertServiceSchema,
  insertClientSchema,
  insertBookingSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Business routes
  app.get("/api/business", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let business = await storage.getUserBusiness(userId);
      if (!business) {
        // Auto-create business for new users
        business = await storage.createBusiness({
          ownerId: userId,
          name: "My Business",
          subscriptionPlan: "free",
        });
      }
      res.json(business);
    } catch (error) {
      console.error("Error fetching business:", error);
      res.status(500).json({ message: "Failed to fetch business" });
    }
  });

  app.post("/api/business", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const businessData = insertBusinessSchema.parse({
        ...req.body,
        ownerId: userId,
      });
      const business = await storage.createBusiness(businessData);
      res.json(business);
    } catch (error) {
      console.error("Error creating business:", error);
      res.status(500).json({ message: "Failed to create business" });
    }
  });

  // Get business by ID (public route for booking forms)
  app.get("/api/business/:businessId", async (req, res) => {
    try {
      const { businessId } = req.params;
      const business = await storage.getBusiness(businessId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      res.json(business);
    } catch (error) {
      console.error("Error fetching business:", error);
      res.status(500).json({ message: "Failed to fetch business" });
    }
  });

  // Staff routes
  app.get("/api/staff", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getUserBusiness(userId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      const staff = await storage.getBusinessStaff(business.id);
      res.json(staff);
    } catch (error) {
      console.error("Error fetching staff:", error);
      res.status(500).json({ message: "Failed to fetch staff" });
    }
  });

  app.post("/api/staff", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getUserBusiness(userId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      const staffData = insertStaffSchema.parse({
        ...req.body,
        businessId: business.id,
      });
      const staff = await storage.createStaff(staffData);
      res.json(staff);
    } catch (error) {
      console.error("Error creating staff:", error);
      res.status(500).json({ message: "Failed to create staff" });
    }
  });

  // Services routes
  app.get("/api/services", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getUserBusiness(userId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      const services = await storage.getBusinessServices(business.id);
      res.json(services);
    } catch (error) {
      console.error("Error fetching services:", error);
      res.status(500).json({ message: "Failed to fetch services" });
    }
  });

  app.post("/api/services", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getUserBusiness(userId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      const serviceData = insertServiceSchema.parse({
        ...req.body,
        businessId: business.id,
      });
      const service = await storage.createService(serviceData);
      res.json(service);
    } catch (error) {
      console.error("Error creating service:", error);
      res.status(500).json({ message: "Failed to create service" });
    }
  });

  app.patch("/api/services/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const serviceData = req.body;
      const service = await storage.updateService(id, serviceData);
      res.json(service);
    } catch (error) {
      console.error("Error updating service:", error);
      res.status(500).json({ message: "Failed to update service" });
    }
  });

  app.delete("/api/services/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteService(id);
      res.json({ message: "Service deleted successfully" });
    } catch (error) {
      console.error("Error deleting service:", error);
      res.status(500).json({ message: "Failed to delete service" });
    }
  });

  // Client routes
  app.get("/api/clients", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getUserBusiness(userId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      const clients = await storage.getBusinessClients(business.id);
      res.json(clients);
    } catch (error) {
      console.error("Error fetching clients:", error);
      res.status(500).json({ message: "Failed to fetch clients" });
    }
  });

  app.post("/api/clients", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getUserBusiness(userId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      const clientData = insertClientSchema.parse({
        ...req.body,
        businessId: business.id,
      });
      const client = await storage.createClient(clientData);
      res.json(client);
    } catch (error) {
      console.error("Error creating client:", error);
      res.status(500).json({ message: "Failed to create client" });
    }
  });

  // Booking routes
  app.get("/api/bookings", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getUserBusiness(userId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      const { startDate, endDate } = req.query;
      const bookings = await storage.getBusinessBookings(
        business.id,
        startDate ? new Date(startDate as string) : undefined,
        endDate ? new Date(endDate as string) : undefined
      );
      res.json(bookings);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  app.post("/api/bookings", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getUserBusiness(userId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      const bookingData = insertBookingSchema.parse({
        ...req.body,
        businessId: business.id,
      });
      const booking = await storage.createBooking(bookingData);
      res.json(booking);
    } catch (error) {
      console.error("Error creating booking:", error);
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  // Analytics routes
  app.get("/api/analytics/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getUserBusiness(userId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      const stats = await storage.getBusinessStats(business.id);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Business update route
  app.patch("/api/business", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let business = await storage.getUserBusiness(userId);
      if (!business) {
        // Auto-create business if it doesn't exist
        business = await storage.createBusiness({
          ownerId: userId,
          name: "My Business",
          subscriptionPlan: "free",
        });
      }
      const updatedBusiness = await storage.updateBusiness(business.id, req.body);
      res.json(updatedBusiness);
    } catch (error) {
      console.error("Error updating business:", error);
      res.status(500).json({ message: "Failed to update business" });
    }
  });

  // Public booking routes
  app.get("/api/business/:businessId", async (req, res) => {
    try {
      const { businessId } = req.params;
      const business = await storage.getBusiness(businessId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      res.json(business);
    } catch (error) {
      console.error("Error fetching business:", error);
      res.status(500).json({ message: "Failed to fetch business" });
    }
  });

  app.get("/api/business/:businessId/services", async (req, res) => {
    try {
      const { businessId } = req.params;
      const services = await storage.getBusinessServices(businessId);
      res.json(services);
    } catch (error) {
      console.error("Error fetching services:", error);
      res.status(500).json({ message: "Failed to fetch services" });
    }
  });

  app.get("/api/business/:businessId/staff", async (req, res) => {
    try {
      const { businessId } = req.params;
      const staff = await storage.getBusinessStaff(businessId);
      res.json(staff);
    } catch (error) {
      console.error("Error fetching staff:", error);
      res.status(500).json({ message: "Failed to fetch staff" });
    }
  });

  // Public booking endpoint for booking form submissions
  app.post("/api/business/:businessId/booking", async (req, res) => {
    try {
      const { businessId } = req.params;
      const bookingData = req.body;
      
      // Create or find client
      let client = await storage.getClientByEmail(businessId, bookingData.clientEmail);
      if (!client) {
        client = await storage.createClient({
          businessId: businessId,
          name: bookingData.clientName,
          email: bookingData.clientEmail,
          phone: bookingData.clientPhone,
        });
      }

      // Create booking with proper date/time combination
      const bookingDateTime = new Date(`${bookingData.date}T${bookingData.time}:00`);
      
      const booking = await storage.createBooking({
        businessId: businessId,
        clientId: client.id,
        serviceId: null, // No service selection in simplified form
        staffId: null,   // No staff selection in simplified form
        date: bookingDateTime,
        status: "pending",
        notes: bookingData.notes || null,
      });

      // Send webhook to n8n if configured
      const business = await storage.getBusiness(businessId);
      if (business?.n8nWebhookUrl) {
        try {
          await fetch(business.n8nWebhookUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              type: 'booking_created',
              booking: {
                ...booking,
                client: {
                  name: client.name,
                  email: client.email,
                  phone: client.phone,
                },
                business: {
                  name: business.name,
                  phone: business.phone,
                  whatsappNumber: business.whatsappNumber,
                }
              },
              timestamp: new Date().toISOString(),
            }),
          });
        } catch (webhookError) {
          console.error('Error sending webhook to n8n:', webhookError);
          // Don't fail the booking if webhook fails
        }
      }

      // Broadcast real-time update to dashboard
      broadcastNewBooking(businessId, {
        ...booking,
        client: {
          name: client.name,
          email: client.email,
          phone: client.phone,
        }
      });

      // Update and broadcast latest stats
      const stats = await storage.getBusinessStats(businessId);
      broadcastStatsUpdate(businessId, stats);

      res.json(booking);
    } catch (error) {
      console.error("Error creating booking:", error);
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  // N8N webhook endpoint for WhatsApp bookings
  app.post("/api/webhooks/n8n/whatsapp-booking", async (req, res) => {
    try {
      const {
        client_name,
        client_phone,
        client_email,
        service_name,
        booking_date,
        booking_time,
        notes,
        source,
        business_id
      } = req.body;

      console.log("Received N8N WhatsApp booking:", req.body);

      // Validate required fields
      if (!client_name || !client_phone || !booking_date || !booking_time || !business_id) {
        return res.status(400).json({ 
          message: "Missing required fields: client_name, client_phone, booking_date, booking_time, business_id" 
        });
      }

      // Find or create client
      let client = await storage.getClientByPhone(business_id, client_phone);
      if (!client) {
        client = await storage.createClient({
          businessId: business_id,
          name: client_name,
          email: client_email || null,
          phone: client_phone,
          notes: `Created via WhatsApp booking - ${new Date().toISOString()}`,
        });
      } else {
        // Update client info if email was provided and not set
        if (client_email && !client.email) {
          await storage.updateClient(client.id, { email: client_email });
        }
      }

      // Find service by name if provided
      let serviceId = null;
      if (service_name) {
        const services = await storage.getBusinessServices(business_id);
        const matchingService = services.find(s => 
          s.name.toLowerCase().includes(service_name.toLowerCase()) ||
          service_name.toLowerCase().includes(s.name.toLowerCase())
        );
        if (matchingService) {
          serviceId = matchingService.id;
        }
      }

      // Create booking with proper date/time combination
      const bookingDateTime = new Date(`${booking_date}T${booking_time}:00`);
      
      const booking = await storage.createBooking({
        businessId: business_id,
        clientId: client.id,
        serviceId: serviceId,
        staffId: null,
        date: bookingDateTime,
        status: "pending",
        notes: notes || `WhatsApp booking created automatically`,
        source: source || "whatsapp",
      });

      // Broadcast real-time update to dashboard
      broadcastNewBooking(business_id, {
        ...booking,
        client: {
          name: client.name,
          email: client.email,
          phone: client.phone,
        },
        service: serviceId ? { name: service_name } : null,
      });

      // Update and broadcast latest stats
      const stats = await storage.getBusinessStats(business_id);
      broadcastStatsUpdate(business_id, stats);

      res.json({ 
        message: "WhatsApp booking created successfully", 
        booking: {
          id: booking.id,
          client_name: client.name,
          client_phone: client.phone,
          booking_date,
          booking_time,
          status: booking.status,
        }
      });

    } catch (error) {
      console.error("Error creating WhatsApp booking:", error);
      res.status(500).json({ message: "Failed to create WhatsApp booking", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // N8N webhook endpoint for booking updates
  app.post("/api/webhooks/n8n/booking-update", async (req, res) => {
    try {
      const { bookingId, status, notes } = req.body;
      
      if (!bookingId || !status) {
        return res.status(400).json({ message: "bookingId and status are required" });
      }

      const booking = await storage.updateBooking(bookingId, {
        status,
        notes: notes || null,
      });

      res.json({ message: "Booking updated successfully", booking });
    } catch (error) {
      console.error("Error updating booking via webhook:", error);
      res.status(500).json({ message: "Failed to update booking" });
    }
  });

  const server = createServer(app);
  
  // Paystack webhook endpoint
  app.post("/api/webhooks/paystack", async (req, res) => {
    try {
      const signature = req.headers['x-paystack-signature'] as string;
      const payload = JSON.stringify(req.body);
      
      if (!verifyPaystackSignature(payload, signature)) {
        return res.status(400).json({ message: "Invalid signature" });
      }
      
      await handlePaystackWebhook(req.body);
      res.status(200).json({ message: "Webhook processed successfully" });
    } catch (error) {
      console.error("Error processing Paystack webhook:", error);
      res.status(500).json({ message: "Failed to process webhook" });
    }
  });

  // Subscription management endpoints
  app.post("/api/subscription/update", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { plan, subscriptionId } = req.body;
      
      let business = await storage.getUserBusiness(userId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      business = await storage.updateBusiness(business.id, {
        subscriptionPlan: plan,
      });

      res.json({ message: "Subscription updated successfully", business });
    } catch (error) {
      console.error("Error updating subscription:", error);
      res.status(500).json({ message: "Failed to update subscription" });
    }
  });

  // Setup WebSocket for real-time updates
  setupWebSocket(server);
  
  return server;
}
