import { storage } from "./storage";

interface PaystackWebhookEvent {
  event: string;
  data: {
    id: number;
    domain: string;
    status: string;
    reference: string;
    amount: number;
    message: string;
    gateway_response: string;
    paid_at: string;
    created_at: string;
    channel: string;
    currency: string;
    ip_address: string;
    metadata: {
      business_id?: string;
      plan_id?: string;
      custom_fields?: Array<{
        display_name: string;
        variable_name: string;
        value: string;
      }>;
    };
    customer: {
      id: number;
      first_name: string;
      last_name: string;
      email: string;
      customer_code: string;
      phone: string;
      metadata: any;
      risk_action: string;
      international_format_phone: string;
    };
    plan: {
      id: number;
      name: string;
      plan_code: string;
      description: string;
      amount: number;
      interval: string;
      send_invoices: boolean;
      send_sms: boolean;
      hosted_page: boolean;
      hosted_page_url: string;
      hosted_page_summary: string;
      currency: string;
      migrate: boolean;
      is_archived: boolean;
      is_deleted: boolean;
      createdAt: string;
      updatedAt: string;
    };
    subscription: {
      id: number;
      domain: string;
      status: string;
      subscription_code: string;
      email_token: string;
      amount: number;
      cron_expression: string;
      next_payment_date: string;
      open_invoice: string;
      createdAt: string;
      updatedAt: string;
      plan: any;
      authorization: any;
      customer: any;
    };
  };
}

export async function handlePaystackWebhook(event: PaystackWebhookEvent) {
  try {
    console.log('Processing Paystack webhook:', event.event);

    switch (event.event) {
      case 'subscription.create':
      case 'subscription.enable':
        await handleSubscriptionActivated(event);
        break;
      
      case 'subscription.disable':
      case 'subscription.not_renew':
        await handleSubscriptionDeactivated(event);
        break;
      
      case 'charge.success':
        await handlePaymentSuccess(event);
        break;
      
      case 'charge.failed':
        await handlePaymentFailed(event);
        break;
      
      default:
        console.log('Unhandled Paystack webhook event:', event.event);
    }
  } catch (error) {
    console.error('Error processing Paystack webhook:', error);
    throw error;
  }
}

async function handleSubscriptionActivated(event: PaystackWebhookEvent) {
  const { business_id, plan_id } = event.data.metadata;
  
  if (!business_id || !plan_id) {
    console.error('Missing business_id or plan_id in webhook metadata');
    return;
  }

  // Update business subscription
  await storage.updateBusiness(business_id, {
    subscriptionPlan: plan_id,
  });

  console.log(`Subscription activated for business ${business_id}, plan: ${plan_id}`);
}

async function handleSubscriptionDeactivated(event: PaystackWebhookEvent) {
  const { business_id } = event.data.metadata;
  
  if (!business_id) {
    console.error('Missing business_id in webhook metadata');
    return;
  }

  // Downgrade to free plan
  await storage.updateBusiness(business_id, {
    subscriptionPlan: 'free',
  });

  console.log(`Subscription deactivated for business ${business_id}, downgraded to free plan`);
}

async function handlePaymentSuccess(event: PaystackWebhookEvent) {
  const { business_id, plan_id } = event.data.metadata;
  
  if (!business_id) {
    console.error('Missing business_id in webhook metadata');
    return;
  }

  console.log(`Payment successful for business ${business_id}, amount: ${event.data.amount / 100} ${event.data.currency}`);
  
  // You can add additional logic here like sending confirmation emails, updating payment history, etc.
}

async function handlePaymentFailed(event: PaystackWebhookEvent) {
  const { business_id } = event.data.metadata;
  
  if (!business_id) {
    console.error('Missing business_id in webhook metadata');
    return;
  }

  console.log(`Payment failed for business ${business_id}`);
  
  // You can add logic here to handle failed payments, like sending notification emails
}

export function verifyPaystackSignature(payload: string, signature: string): boolean {
  const crypto = require('crypto');
  const secret = process.env.PAYSTACK_SECRET_KEY;
  
  if (!secret) {
    console.error('PAYSTACK_SECRET_KEY is not set');
    return false;
  }

  const hash = crypto.createHmac('sha512', secret).update(payload).digest('hex');
  return hash === signature;
}