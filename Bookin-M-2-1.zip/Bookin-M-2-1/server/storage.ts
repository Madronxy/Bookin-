import {
  users,
  businesses,
  staff,
  services,
  clients,
  bookings,
  type User,
  type UpsertUser,
  type Business,
  type InsertBusiness,
  type Staff,
  type InsertStaff,
  type Service,
  type InsertService,
  type Client,
  type InsertClient,
  type Booking,
  type InsertBooking,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, count, gte, lte } from "drizzle-orm";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Business operations
  getUserBusiness(userId: string): Promise<Business | undefined>;
  getBusiness(id: string): Promise<Business | undefined>;
  createBusiness(business: InsertBusiness): Promise<Business>;
  updateBusiness(id: string, business: Partial<InsertBusiness>): Promise<Business>;

  // Staff operations
  getBusinessStaff(businessId: string): Promise<Staff[]>;
  createStaff(staff: InsertStaff): Promise<Staff>;
  updateStaff(id: string, staff: Partial<InsertStaff>): Promise<Staff>;
  deleteStaff(id: string): Promise<void>;

  // Service operations
  getBusinessServices(businessId: string): Promise<Service[]>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: string, service: Partial<InsertService>): Promise<Service>;
  deleteService(id: string): Promise<void>;

  // Client operations
  getBusinessClients(businessId: string): Promise<Client[]>;
  getClientByEmail(businessId: string, email: string): Promise<Client | undefined>;
  getClientByPhone(businessId: string, phone: string): Promise<Client | undefined>;
  searchClients(businessId: string, query: string): Promise<Client[]>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: string, client: Partial<InsertClient>): Promise<Client>;
  deleteClient(id: string): Promise<void>;

  // Booking operations
  getBusinessBookings(businessId: string, startDate?: Date, endDate?: Date): Promise<(Booking & { client: Client; service: Service; staff: Staff | null })[]>;
  getTodayBookings(businessId: string): Promise<number>;
  getUpcomingBookings(businessId: string): Promise<number>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBooking(id: string, booking: Partial<InsertBooking>): Promise<Booking>;
  deleteBooking(id: string): Promise<void>;

  // Analytics
  getBusinessStats(businessId: string): Promise<{
    todayBookings: number;
    upcomingBookings: number;
    activeClients: number;
    totalRevenue: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  private get database() {
    if (!db) {
      throw new Error('Database connection not available');
    }
    return db;
  }

  // User operations - mandatory for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await this.database.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await this.database
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Business operations
  async getUserBusiness(userId: string): Promise<Business | undefined> {
    const [business] = await this.database
      .select()
      .from(businesses)
      .where(eq(businesses.ownerId, userId));
    return business;
  }

  async createBusiness(business: InsertBusiness): Promise<Business> {
    const [newBusiness] = await this.database
      .insert(businesses)
      .values(business)
      .returning();
    return newBusiness;
  }

  async updateBusiness(id: string, business: Partial<InsertBusiness>): Promise<Business> {
    const [updatedBusiness] = await this.database
      .update(businesses)
      .set({ ...business, updatedAt: new Date() })
      .where(eq(businesses.id, id))
      .returning();
    return updatedBusiness;
  }

  async getBusiness(id: string): Promise<Business | undefined> {
    const [business] = await this.database.select().from(businesses).where(eq(businesses.id, id));
    return business;
  }

  async getClientByEmail(businessId: string, email: string): Promise<Client | undefined> {
    const [client] = await this.database
      .select()
      .from(clients)
      .where(and(eq(clients.businessId, businessId), eq(clients.email, email)));
    return client;
  }

  // Staff operations
  async getBusinessStaff(businessId: string): Promise<Staff[]> {
    return await this.database
      .select()
      .from(staff)
      .where(eq(staff.businessId, businessId))
      .orderBy(staff.name);
  }

  async createStaff(staffData: InsertStaff): Promise<Staff> {
    const [newStaff] = await this.database
      .insert(staff)
      .values(staffData)
      .returning();
    return newStaff;
  }

  async updateStaff(id: string, staffData: Partial<InsertStaff>): Promise<Staff> {
    const [updatedStaff] = await this.database
      .update(staff)
      .set({ ...staffData, updatedAt: new Date() })
      .where(eq(staff.id, id))
      .returning();
    return updatedStaff;
  }

  async deleteStaff(id: string): Promise<void> {
    await this.database.delete(staff).where(eq(staff.id, id));
  }

  // Service operations
  async getBusinessServices(businessId: string): Promise<Service[]> {
    return await this.database
      .select()
      .from(services)
      .where(eq(services.businessId, businessId))
      .orderBy(services.name);
  }

  async createService(serviceData: InsertService): Promise<Service> {
    const [newService] = await this.database
      .insert(services)
      .values(serviceData)
      .returning();
    return newService;
  }

  async updateService(id: string, serviceData: Partial<InsertService>): Promise<Service> {
    const [updatedService] = await this.database
      .update(services)
      .set({ ...serviceData, updatedAt: new Date() })
      .where(eq(services.id, id))
      .returning();
    return updatedService;
  }

  async deleteService(id: string): Promise<void> {
    await this.database.delete(services).where(eq(services.id, id));
  }

  // Client operations
  async getBusinessClients(businessId: string): Promise<Client[]> {
    return await this.database
      .select()
      .from(clients)
      .where(eq(clients.businessId, businessId))
      .orderBy(desc(clients.createdAt));
  }



  async searchClients(businessId: string, query: string): Promise<Client[]> {
    return await this.database
      .select()
      .from(clients)
      .where(
        and(
          eq(clients.businessId, businessId),
          // Simple search implementation - can be enhanced with full-text search
        )
      )
      .orderBy(clients.name);
  }

  async createClient(clientData: InsertClient): Promise<Client> {
    const [newClient] = await this.database
      .insert(clients)
      .values(clientData)
      .returning();
    return newClient;
  }

  async updateClient(id: string, clientData: Partial<InsertClient>): Promise<Client> {
    const [updatedClient] = await this.database
      .update(clients)
      .set({ ...clientData, updatedAt: new Date() })
      .where(eq(clients.id, id))
      .returning();
    return updatedClient;
  }

  async deleteClient(id: string): Promise<void> {
    await this.database.delete(clients).where(eq(clients.id, id));
  }

  async getClientByPhone(businessId: string, phone: string): Promise<any> {
    const [client] = await this.database
      .select()
      .from(clients)
      .where(and(eq(clients.businessId, businessId), eq(clients.phone, phone)))
      .limit(1);
    return client;
  }

  // Booking operations
  async getBusinessBookings(
    businessId: string,
    startDate?: Date,
    endDate?: Date
  ): Promise<(Booking & { client: Client; service: Service; staff: Staff | null })[]> {
    let query = this.database
      .select({
        id: bookings.id,
        businessId: bookings.businessId,
        clientId: bookings.clientId,
        serviceId: bookings.serviceId,
        staffId: bookings.staffId,
        date: bookings.date,
        status: bookings.status,
        notes: bookings.notes,
        source: bookings.source,
        createdAt: bookings.createdAt,
        updatedAt: bookings.updatedAt,
        client: clients,
        service: services,
        staff: staff,
      })
      .from(bookings)
      .leftJoin(clients, eq(bookings.clientId, clients.id))
      .leftJoin(services, eq(bookings.serviceId, services.id))
      .leftJoin(staff, eq(bookings.staffId, staff.id))
      .where(eq(bookings.businessId, businessId));

    if (startDate && endDate) {
      query = this.database
        .select({
          id: bookings.id,
          businessId: bookings.businessId,
          clientId: bookings.clientId,
          serviceId: bookings.serviceId,
          staffId: bookings.staffId,
          date: bookings.date,
          status: bookings.status,
          notes: bookings.notes,
          source: bookings.source,
          createdAt: bookings.createdAt,
          updatedAt: bookings.updatedAt,
          client: clients,
          service: services,
          staff: staff,
        })
        .from(bookings)
        .leftJoin(clients, eq(bookings.clientId, clients.id))
        .leftJoin(services, eq(bookings.serviceId, services.id))
        .leftJoin(staff, eq(bookings.staffId, staff.id))
        .where(
          and(
            eq(bookings.businessId, businessId),
            gte(bookings.date, startDate),
            lte(bookings.date, endDate)
          )
        );
    }

    const results = await query.orderBy(bookings.date);
    return results.map(row => ({
      ...row,
      client: row.client!,
      service: row.service!,
      staff: row.staff
    }));
  }

  async getTodayBookings(businessId: string): Promise<number> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const [result] = await this.database
      .select({ count: count() })
      .from(bookings)
      .where(
        and(
          eq(bookings.businessId, businessId),
          gte(bookings.date, today),
          lte(bookings.date, tomorrow)
        )
      );

    return result.count;
  }

  async getUpcomingBookings(businessId: string): Promise<number> {
    const now = new Date();
    const next24Hours = new Date(now.getTime() + 24 * 60 * 60 * 1000);

    const [result] = await this.database
      .select({ count: count() })
      .from(bookings)
      .where(
        and(
          eq(bookings.businessId, businessId),
          gte(bookings.date, now),
          lte(bookings.date, next24Hours)
        )
      );

    return result.count;
  }

  async createBooking(bookingData: InsertBooking): Promise<Booking> {
    const [newBooking] = await this.database
      .insert(bookings)
      .values(bookingData)
      .returning();

    // Get current client and increment total visits
    const [currentClient] = await this.database
      .select()
      .from(clients)
      .where(eq(clients.id, newBooking.clientId));

    if (currentClient) {
      await this.database
        .update(clients)
        .set({
          lastBooking: newBooking.date,
          totalVisits: (currentClient.totalVisits || 0) + 1,
          updatedAt: new Date(),
        })
        .where(eq(clients.id, newBooking.clientId));
    }

    return newBooking;
  }

  async updateBooking(id: string, bookingData: Partial<InsertBooking>): Promise<Booking> {
    const [updatedBooking] = await this.database
      .update(bookings)
      .set({ ...bookingData, updatedAt: new Date() })
      .where(eq(bookings.id, id))
      .returning();
    return updatedBooking;
  }

  async deleteBooking(id: string): Promise<void> {
    await this.database.delete(bookings).where(eq(bookings.id, id));
  }

  // Analytics
  async getBusinessStats(businessId: string): Promise<{
    todayBookings: number;
    upcomingBookings: number;
    activeClients: number;
    totalRevenue: number;
  }> {
    const todayBookings = await this.getTodayBookings(businessId);
    const upcomingBookings = await this.getUpcomingBookings(businessId);

    // Active clients this month
    const thisMonthStart = new Date();
    thisMonthStart.setDate(1);
    thisMonthStart.setHours(0, 0, 0, 0);

    const [activeClientsResult] = await this.database
      .select({ count: count() })
      .from(clients)
      .where(
        and(
          eq(clients.businessId, businessId),
          gte(clients.lastBooking, thisMonthStart)
        )
      );

    return {
      todayBookings,
      upcomingBookings,
      activeClients: activeClientsResult.count,
      totalRevenue: 0, // Can be calculated from completed bookings
    };
  }
}

// In-memory storage implementation for when database is unavailable
export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private businesses: Map<string, Business> = new Map();
  private staff: Map<string, Staff> = new Map();
  private services: Map<string, Service> = new Map();
  private clients: Map<string, Client> = new Map();
  private bookings: Map<string, Booking> = new Map();

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existing = this.users.get(userData.id!);
    const user: User = {
      id: userData.id!,
      email: userData.email ?? null,
      firstName: userData.firstName ?? null,
      lastName: userData.lastName ?? null,
      profileImageUrl: userData.profileImageUrl ?? null,
      createdAt: existing?.createdAt ?? new Date(),
      updatedAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }

  async getUserBusiness(userId: string): Promise<Business | undefined> {
    return Array.from(this.businesses.values()).find(b => b.ownerId === userId);
  }

  async createBusiness(business: InsertBusiness): Promise<Business> {
    const newBusiness: Business = {
      id: crypto.randomUUID(),
      ownerId: business.ownerId,
      name: business.name,
      email: business.email ?? null,
      logoUrl: business.logoUrl ?? null,
      phone: business.phone ?? null,
      address: business.address ?? null,
      description: business.description ?? null,
      website: business.website ?? null,
      businessHours: business.businessHours ?? null,
      subscriptionPlan: business.subscriptionPlan ?? "free",
      joinDate: business.joinDate ?? new Date(),
      bookingQrUrl: business.bookingQrUrl ?? null,
      whatsappQrUrl: business.whatsappQrUrl ?? null,
      whatsappNumber: business.whatsappNumber ?? null,
      whatsappApiKey: business.whatsappApiKey ?? null,
      n8nWebhookUrl: business.n8nWebhookUrl ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.businesses.set(newBusiness.id, newBusiness);
    return newBusiness;
  }

  async updateBusiness(id: string, business: Partial<InsertBusiness>): Promise<Business> {
    const existing = this.businesses.get(id);
    if (!existing) throw new Error("Business not found");
    const updated = { ...existing, ...business, updatedAt: new Date() };
    this.businesses.set(id, updated);
    return updated;
  }

  async getBusiness(id: string): Promise<Business | undefined> {
    return this.businesses.get(id);
  }

  async getBusinessStaff(businessId: string): Promise<Staff[]> {
    return Array.from(this.staff.values()).filter(s => s.businessId === businessId);
  }

  async createStaff(staffData: InsertStaff): Promise<Staff> {
    const newStaff: Staff = {
      id: crypto.randomUUID(),
      businessId: staffData.businessId,
      userId: staffData.userId ?? null,
      name: staffData.name,
      email: staffData.email ?? null,
      role: staffData.role,
      specialties: staffData.specialties ?? null,
      workingHours: staffData.workingHours ?? null,
      isActive: staffData.isActive ?? true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.staff.set(newStaff.id, newStaff);
    return newStaff;
  }

  async updateStaff(id: string, staffData: Partial<InsertStaff>): Promise<Staff> {
    const existing = this.staff.get(id);
    if (!existing) throw new Error("Staff not found");
    const updated = { ...existing, ...staffData, updatedAt: new Date() };
    this.staff.set(id, updated);
    return updated;
  }

  async deleteStaff(id: string): Promise<void> {
    this.staff.delete(id);
  }

  async getBusinessServices(businessId: string): Promise<Service[]> {
    return Array.from(this.services.values()).filter(s => s.businessId === businessId);
  }

  async createService(serviceData: InsertService): Promise<Service> {
    const newService: Service = {
      id: crypto.randomUUID(),
      businessId: serviceData.businessId,
      name: serviceData.name,
      description: serviceData.description ?? null,
      price: serviceData.price,
      duration: serviceData.duration,
      isActive: serviceData.isActive ?? true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.services.set(newService.id, newService);
    return newService;
  }

  async updateService(id: string, serviceData: Partial<InsertService>): Promise<Service> {
    const existing = this.services.get(id);
    if (!existing) throw new Error("Service not found");
    const updated = { ...existing, ...serviceData, updatedAt: new Date() };
    this.services.set(id, updated);
    return updated;
  }

  async deleteService(id: string): Promise<void> {
    this.services.delete(id);
  }

  async getBusinessClients(businessId: string): Promise<Client[]> {
    return Array.from(this.clients.values()).filter(c => c.businessId === businessId);
  }

  async getClientByEmail(businessId: string, email: string): Promise<Client | undefined> {
    return Array.from(this.clients.values()).find(c => c.businessId === businessId && c.email === email);
  }

  async getClientByPhone(businessId: string, phone: string): Promise<Client | undefined> {
    return Array.from(this.clients.values()).find(c => c.businessId === businessId && c.phone === phone);
  }

  async searchClients(businessId: string, query: string): Promise<Client[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.clients.values()).filter(
      c => c.businessId === businessId && 
           (c.name.toLowerCase().includes(lowerQuery) || 
            c.email?.toLowerCase().includes(lowerQuery) ||
            c.phone?.toLowerCase().includes(lowerQuery))
    );
  }

  async createClient(clientData: InsertClient): Promise<Client> {
    const newClient: Client = {
      id: crypto.randomUUID(),
      businessId: clientData.businessId,
      name: clientData.name,
      phone: clientData.phone ?? null,
      email: clientData.email ?? null,
      tags: clientData.tags ?? null,
      notes: clientData.notes ?? null,
      totalVisits: clientData.totalVisits ?? 0,
      lastBooking: clientData.lastBooking ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.clients.set(newClient.id, newClient);
    return newClient;
  }

  async updateClient(id: string, clientData: Partial<InsertClient>): Promise<Client> {
    const existing = this.clients.get(id);
    if (!existing) throw new Error("Client not found");
    const updated = { ...existing, ...clientData, updatedAt: new Date() };
    this.clients.set(id, updated);
    return updated;
  }

  async deleteClient(id: string): Promise<void> {
    this.clients.delete(id);
  }

  async getBusinessBookings(businessId: string, startDate?: Date, endDate?: Date): Promise<(Booking & { client: Client; service: Service; staff: Staff | null })[]> {
    let bookingList = Array.from(this.bookings.values()).filter(b => b.businessId === businessId);
    
    if (startDate) {
      bookingList = bookingList.filter(b => b.date >= startDate);
    }
    if (endDate) {
      bookingList = bookingList.filter(b => b.date <= endDate);
    }

    return bookingList.map(b => ({
      ...b,
      client: this.clients.get(b.clientId)!,
      service: this.services.get(b.serviceId!)!,
      staff: b.staffId ? this.staff.get(b.staffId) || null : null,
    }));
  }

  async getTodayBookings(businessId: string): Promise<number> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    return Array.from(this.bookings.values()).filter(
      b => b.businessId === businessId && b.date >= today && b.date < tomorrow
    ).length;
  }

  async getUpcomingBookings(businessId: string): Promise<number> {
    const now = new Date();
    return Array.from(this.bookings.values()).filter(
      b => b.businessId === businessId && b.date > now && b.status !== "cancelled"
    ).length;
  }

  async createBooking(bookingData: InsertBooking): Promise<Booking> {
    const newBooking: Booking = {
      id: crypto.randomUUID(),
      businessId: bookingData.businessId,
      clientId: bookingData.clientId,
      serviceId: bookingData.serviceId ?? null,
      staffId: bookingData.staffId ?? null,
      date: bookingData.date,
      status: bookingData.status ?? "pending",
      notes: bookingData.notes ?? null,
      source: bookingData.source ?? "dashboard",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.bookings.set(newBooking.id, newBooking);
    return newBooking;
  }

  async updateBooking(id: string, bookingData: Partial<InsertBooking>): Promise<Booking> {
    const existing = this.bookings.get(id);
    if (!existing) throw new Error("Booking not found");
    const updated = { ...existing, ...bookingData, updatedAt: new Date() };
    this.bookings.set(id, updated);
    return updated;
  }

  async deleteBooking(id: string): Promise<void> {
    this.bookings.delete(id);
  }

  async getBusinessStats(businessId: string): Promise<{
    todayBookings: number;
    upcomingBookings: number;
    activeClients: number;
    totalRevenue: number;
  }> {
    const todayBookings = await this.getTodayBookings(businessId);
    const upcomingBookings = await this.getUpcomingBookings(businessId);
    
    const thisMonthStart = new Date();
    thisMonthStart.setDate(1);
    thisMonthStart.setHours(0, 0, 0, 0);
    
    const activeClients = Array.from(this.clients.values()).filter(
      c => c.businessId === businessId && c.lastBooking && c.lastBooking >= thisMonthStart
    ).length;

    return {
      todayBookings,
      upcomingBookings,
      activeClients,
      totalRevenue: 0,
    };
  }
}

// Use database storage if DATABASE_URL is available, otherwise fall back to in-memory
const connectionString = process.env.PGHOST || process.env.DATABASE_URL;

export const storage: IStorage = connectionString 
  ? new DatabaseStorage()
  : new MemStorage();

if (connectionString) {
  console.log('✓ Using persistent database storage');
} else {
  console.log('⚠️  Using in-memory data storage. Data will not persist across server restarts.');
}
