import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { storage } from './storage';

interface ClientConnection {
  ws: WebSocket;
  businessId?: string;
  userId?: string;
}

const clients = new Map<string, ClientConnection>();

export function setupWebSocket(server: Server) {
  const wss = new WebSocketServer({ 
    server, 
    path: '/ws',
    verifyClient: (info: any) => {
      // Add any authentication logic here if needed
      return true;
    }
  });

  wss.on('connection', (ws, request) => {
    const clientId = generateClientId();
    console.log(`WebSocket client connected: ${clientId}`);

    // Store the connection
    clients.set(clientId, { ws });

    // Handle messages from client
    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        await handleMessage(clientId, message);
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
        ws.send(JSON.stringify({ 
          type: 'error', 
          message: 'Invalid message format' 
        }));
      }
    });

    // Handle client disconnect
    ws.on('close', () => {
      console.log(`WebSocket client disconnected: ${clientId}`);
      clients.delete(clientId);
    });

    // Handle errors
    ws.on('error', (error) => {
      console.error(`WebSocket error for client ${clientId}:`, error);
      clients.delete(clientId);
    });

    // Send welcome message
    ws.send(JSON.stringify({ 
      type: 'connected', 
      clientId,
      message: 'Connected to BOOKin real-time updates' 
    }));
  });

  return wss;
}

async function handleMessage(clientId: string, message: any) {
  const client = clients.get(clientId);
  if (!client) return;

  switch (message.type) {
    case 'authenticate':
      // Store business/user association for this client
      client.businessId = message.businessId;
      client.userId = message.userId;
      
      client.ws.send(JSON.stringify({
        type: 'authenticated',
        businessId: message.businessId
      }));
      break;

    case 'ping':
      client.ws.send(JSON.stringify({ type: 'pong' }));
      break;

    default:
      client.ws.send(JSON.stringify({
        type: 'error',
        message: `Unknown message type: ${message.type}`
      }));
  }
}

// Broadcast functions for real-time updates
export function broadcastToBusinessClients(businessId: string, data: any) {
  clients.forEach((client) => {
    if (client.businessId === businessId && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(JSON.stringify(data));
    }
  });
}

export function broadcastNewBooking(businessId: string, booking: any) {
  broadcastToBusinessClients(businessId, {
    type: 'new_booking',
    booking,
    timestamp: new Date().toISOString()
  });
}

export function broadcastBookingUpdate(businessId: string, booking: any) {
  broadcastToBusinessClients(businessId, {
    type: 'booking_updated',
    booking,
    timestamp: new Date().toISOString()
  });
}

export function broadcastStatsUpdate(businessId: string, stats: any) {
  broadcastToBusinessClients(businessId, {
    type: 'stats_updated',
    stats,
    timestamp: new Date().toISOString()
  });
}

function generateClientId(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}