import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Settings, 
  Building2, 
  Phone, 
  Mail, 
  MapPin, 
  MessageSquare, 
  Webhook,
  QrCode,
  Save,
  Download,
  Copy,
  ExternalLink
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { generateQRCodeDataURL } from "@/lib/qr-generator";
import BusinessHours from "@/components/dashboard/business-hours";
import type { Business } from "@shared/schema";

const businessInfoSchema = z.object({
  name: z.string().min(1, "Business name is required"),
  email: z.string().email("Invalid email address").optional().or(z.literal("")),
  phone: z.string().optional(),
  address: z.string().optional(),
  description: z.string().optional(),
  website: z.string().url("Invalid website URL").optional().or(z.literal("")),
});

const whatsappConfigSchema = z.object({
  whatsappNumber: z.string().min(1, "WhatsApp number is required"),
  whatsappApiKey: z.string().optional(),
});

const n8nConfigSchema = z.object({
  n8nWebhookUrl: z.string().url("Invalid webhook URL").optional().or(z.literal("")),
});

type BusinessInfoForm = z.infer<typeof businessInfoSchema>;
type WhatsAppConfigForm = z.infer<typeof whatsappConfigSchema>;
type N8nConfigForm = z.infer<typeof n8nConfigSchema>;

export default function BusinessSettingsPage() {
  const [activeTab, setActiveTab] = useState("general");

  const { data: business, isLoading } = useQuery<Business>({
    queryKey: ["/api/business"],
  });

  const businessForm = useForm<BusinessInfoForm>({
    resolver: zodResolver(businessInfoSchema),
    defaultValues: {
      name: business?.name || "",
      email: business?.email || "",
      phone: business?.phone || "",
      address: business?.address || "",
      description: business?.description || "",
      website: business?.website || "",
    },
  });

  const whatsappForm = useForm<WhatsAppConfigForm>({
    resolver: zodResolver(whatsappConfigSchema),
    defaultValues: {
      whatsappNumber: business?.whatsappNumber || "",
      whatsappApiKey: business?.whatsappApiKey || "",
    },
  });

  const n8nForm = useForm<N8nConfigForm>({
    resolver: zodResolver(n8nConfigSchema),
    defaultValues: {
      n8nWebhookUrl: business?.n8nWebhookUrl || "",
    },
  });

  // Update forms when business data loads
  if (business && !businessForm.getValues().name) {
    businessForm.reset({
      name: business.name || "",
      email: business.email || "",
      phone: business.phone || "",
      address: business.address || "",
      description: business.description || "",
      website: business.website || "",
    });
    whatsappForm.reset({
      whatsappNumber: business.whatsappNumber || "",
      whatsappApiKey: business.whatsappApiKey || "",
    });
    n8nForm.reset({
      n8nWebhookUrl: business.n8nWebhookUrl || "",
    });
  }

  const updateBusinessMutation = useMutation({
    mutationFn: (data: Partial<Business>) => 
      apiRequest("/api/business", {
        method: "PATCH",
        body: data,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/business"] });
      toast({
        title: "Settings Updated",
        description: "Your business settings have been saved successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onBusinessInfoSubmit = (data: BusinessInfoForm) => {
    updateBusinessMutation.mutate(data);
  };

  const onWhatsAppConfigSubmit = (data: WhatsAppConfigForm) => {
    updateBusinessMutation.mutate(data);
  };

  const onN8nConfigSubmit = (data: N8nConfigForm) => {
    updateBusinessMutation.mutate(data);
  };

  const downloadQRCode = async (type: 'booking' | 'whatsapp') => {
    if (!business?.id) return;

    const url = type === 'booking' 
      ? `${window.location.origin}/book/${business.id}`
      : business.whatsappNumber 
        ? `https://wa.me/${business.whatsappNumber.replace(/[^0-9]/g, '')}?text=Hi, I would like to book an appointment`
        : '';

    if (!url) {
      toast({
        title: "Error",
        description: "WhatsApp number not configured",
        variant: "destructive",
      });
      return;
    }

    try {
      const dataUrl = await generateQRCodeDataURL(url);
      const link = document.createElement('a');
      link.download = `${business.name}-${type}-qr-code.png`;
      link.href = dataUrl;
      link.click();
      
      toast({
        title: "QR Code Downloaded",
        description: `${type} QR code has been downloaded successfully.`,
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Failed to generate QR code",
        variant: "destructive",
      });
    }
  };

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: `${label} copied to clipboard.`,
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-700 rounded w-1/3"></div>
          <div className="h-64 bg-gray-700 rounded"></div>
        </div>
      </div>
    );
  }

  const bookingUrl = business?.id ? `${window.location.origin}/book/${business.id}` : '';
  const whatsappUrl = business?.whatsappNumber 
    ? `https://wa.me/${business.whatsappNumber.replace(/[^0-9]/g, '')}?text=Hi, I would like to book an appointment`
    : '';

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center space-x-3">
        <Settings className="h-8 w-8 text-teal-400" />
        <div>
          <h1 className="text-3xl font-bold text-white">Business Settings</h1>
          <p className="text-gray-400">Manage your business information and integrations</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5 bg-gray-800">
          <TabsTrigger value="general" className="text-white">General</TabsTrigger>
          <TabsTrigger value="qr-codes" className="text-white">QR Codes</TabsTrigger>
          <TabsTrigger value="hours" className="text-white">Hours</TabsTrigger>
          <TabsTrigger value="whatsapp" className="text-white">WhatsApp</TabsTrigger>
          <TabsTrigger value="integrations" className="text-white">Integrations</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Building2 className="w-5 h-5 mr-2 text-teal-400" />
                Business Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={businessForm.handleSubmit(onBusinessInfoSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-white">Business Name *</Label>
                    <Input
                      {...businessForm.register("name")}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="Your Business Name"
                    />
                    {businessForm.formState.errors.name && (
                      <p className="text-red-400 text-sm">{businessForm.formState.errors.name.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-white">Email</Label>
                    <Input
                      {...businessForm.register("email")}
                      type="email"
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="business@example.com"
                    />
                    {businessForm.formState.errors.email && (
                      <p className="text-red-400 text-sm">{businessForm.formState.errors.email.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-white">Phone</Label>
                    <Input
                      {...businessForm.register("phone")}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="website" className="text-white">Website</Label>
                    <Input
                      {...businessForm.register("website")}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="https://yourwebsite.com"
                    />
                    {businessForm.formState.errors.website && (
                      <p className="text-red-400 text-sm">{businessForm.formState.errors.website.message}</p>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address" className="text-white">Address</Label>
                  <Textarea
                    {...businessForm.register("address")}
                    className="bg-gray-800 border-gray-600 text-white"
                    rows={2}
                    placeholder="123 Main St, City, State 12345"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description" className="text-white">Description</Label>
                  <Textarea
                    {...businessForm.register("description")}
                    className="bg-gray-800 border-gray-600 text-white"
                    rows={3}
                    placeholder="Describe your business..."
                  />
                </div>

                <Button
                  type="submit"
                  disabled={updateBusinessMutation.isPending}
                  className="bg-gradient-to-r from-teal-600 to-purple-600 hover:from-teal-700 hover:to-purple-700"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {updateBusinessMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="qr-codes">
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Booking QR Code */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <QrCode className="w-5 h-5 mr-2 text-blue-400" />
                    Booking QR Code
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-center">
                    {bookingUrl ? (
                      <div className="bg-white p-4 rounded-lg flex items-center justify-center">
                        <div className="w-48 h-48 flex items-center justify-center text-gray-500">
                          QR Preview - Use new QR page for scannable codes
                        </div>
                      </div>
                    ) : (
                      <div className="w-48 h-48 bg-gray-700 rounded-lg flex items-center justify-center">
                        <p className="text-gray-400 text-sm text-center">
                          Business not configured
                        </p>
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-white">Booking URL:</Label>
                    <div className="flex space-x-2">
                      <Input
                        value={bookingUrl}
                        readOnly
                        className="bg-gray-800 border-gray-600 text-white text-sm"
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(bookingUrl, "Booking URL")}
                        className="border-gray-600"
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      onClick={() => downloadQRCode('booking')}
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                      disabled={!bookingUrl}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                    <Button
                      onClick={() => window.open(bookingUrl, '_blank')}
                      variant="outline"
                      className="border-gray-600"
                      disabled={!bookingUrl}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* WhatsApp QR Code */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <MessageSquare className="w-5 h-5 mr-2 text-green-400" />
                    WhatsApp QR Code
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-center">
                    {whatsappUrl ? (
                      <div className="bg-white p-4 rounded-lg flex items-center justify-center">
                        <div className="w-48 h-48 flex items-center justify-center text-gray-500">
                          QR Preview - Use new QR page for scannable codes
                        </div>
                      </div>
                    ) : (
                      <div className="w-48 h-48 bg-gray-700 rounded-lg flex items-center justify-center">
                        <p className="text-gray-400 text-sm text-center">
                          Configure WhatsApp first
                        </p>
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-white">WhatsApp URL:</Label>
                    <div className="flex space-x-2">
                      <Input
                        value={whatsappUrl}
                        readOnly
                        className="bg-gray-800 border-gray-600 text-white text-sm"
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(whatsappUrl, "WhatsApp URL")}
                        className="border-gray-600"
                        disabled={!whatsappUrl}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      onClick={() => downloadQRCode('whatsapp')}
                      className="flex-1 bg-green-600 hover:bg-green-700"
                      disabled={!whatsappUrl}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                    <Button
                      onClick={() => window.open(whatsappUrl, '_blank')}
                      variant="outline"
                      className="border-gray-600"
                      disabled={!whatsappUrl}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-yellow-900/20 border-yellow-700">
              <CardContent className="pt-6">
                <h3 className="text-yellow-400 font-medium mb-2">Usage Tips</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-yellow-200">
                  <div>
                    <h4 className="font-medium text-yellow-300 mb-1">Booking QR Code</h4>
                    <ul className="space-y-1">
                      <li>• Place on business cards and flyers</li>
                      <li>• Display at your reception or storefront</li>
                      <li>• Great for walk-in customers</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-yellow-300 mb-1">WhatsApp QR Code</h4>
                    <ul className="space-y-1">
                      <li>• Enable quick WhatsApp bookings</li>
                      <li>• Great for walk-in customers</li>
                      <li>• Perfect for social media sharing</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="whatsapp">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <MessageSquare className="w-5 h-5 mr-2 text-green-400" />
                WhatsApp Configuration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={whatsappForm.handleSubmit(onWhatsAppConfigSubmit)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="whatsappNumber" className="text-white">WhatsApp Number *</Label>
                  <Input
                    {...whatsappForm.register("whatsappNumber")}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="+27677544213"
                  />
                  <p className="text-gray-400 text-sm">
                    Enter your WhatsApp number to enable WhatsApp booking integration
                  </p>
                  {whatsappForm.formState.errors.whatsappNumber && (
                    <p className="text-red-400 text-sm">{whatsappForm.formState.errors.whatsappNumber.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="whatsappApiKey" className="text-white">WhatsApp API Key (Optional)</Label>
                  <Input
                    {...whatsappForm.register("whatsappApiKey")}
                    type="password"
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Your WhatsApp Business API key"
                  />
                  <p className="text-gray-400 text-sm">
                    For advanced WhatsApp Business API integration (optional)
                  </p>
                </div>

                <Button
                  type="submit"
                  disabled={updateBusinessMutation.isPending}
                  className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {updateBusinessMutation.isPending ? "Saving..." : "Save WhatsApp Settings"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="hours">
          <BusinessHours />
        </TabsContent>

        <TabsContent value="integrations">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Webhook className="w-5 h-5 mr-2 text-purple-400" />
                N8N Automation Integration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={n8nForm.handleSubmit(onN8nConfigSubmit)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="n8nWebhookUrl" className="text-white">N8N Webhook URL</Label>
                  <Input
                    {...n8nForm.register("n8nWebhookUrl")}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="https://your-n8n-instance.com/webhook/booking-updates"
                  />
                  <p className="text-gray-400 text-sm">
                    BOOKin will send booking notifications to this webhook URL for automation
                  </p>
                  {n8nForm.formState.errors.n8nWebhookUrl && (
                    <p className="text-red-400 text-sm">{n8nForm.formState.errors.n8nWebhookUrl.message}</p>
                  )}
                </div>

                <Button
                  type="submit"
                  disabled={updateBusinessMutation.isPending}
                  className="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {updateBusinessMutation.isPending ? "Saving..." : "Save Integration Settings"}
                </Button>
              </form>

              <Separator className="my-6 bg-gray-600" />

              <div className="space-y-4">
                <h3 className="text-white font-medium">Webhook Information</h3>
                <div className="bg-gray-800 p-4 rounded-lg space-y-3">
                  <div>
                    <Label className="text-gray-300">Booking Creation Webhook:</Label>
                    <p className="text-sm text-gray-400 mt-1">
                      Sends POST request when new bookings are created via the booking form
                    </p>
                  </div>
                  <div>
                    <Label className="text-gray-300">Update Webhook Endpoint:</Label>
                    <code className="block text-sm bg-gray-900 p-2 rounded text-green-400 mt-1">
                      POST {window.location.origin}/api/webhooks/n8n/booking-update
                    </code>
                    <p className="text-sm text-gray-400 mt-1">
                      Use this endpoint to update booking status from your n8n workflow
                    </p>
                  </div>
                  <div>
                    <Label className="text-gray-300">Expected Payload:</Label>
                    <pre className="text-sm bg-gray-900 p-2 rounded text-green-400 mt-1 overflow-x-auto">
{`{
  "bookingId": "uuid",
  "status": "confirmed|completed|cancelled",
  "notes": "Optional update notes"
}`}
                    </pre>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}