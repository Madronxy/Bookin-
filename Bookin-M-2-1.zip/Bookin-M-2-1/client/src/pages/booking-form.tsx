import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Clock } from "lucide-react";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function BookingForm() {
  const { businessId } = useParams<{ businessId: string }>();
  const [formData, setFormData] = useState({
    name: "",
    email: "", 
    phone: "",
    date: null as Date | null,
    time: "",
    serviceId: "",
    comments: "",
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: business } = useQuery({
    queryKey: ["/api/business/public", businessId],
    enabled: !!businessId,
  });

  const { data: services = [] } = useQuery({
    queryKey: ["/api/services/public", businessId], 
    enabled: !!businessId,
  });

  const createBookingMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("/api/bookings/public", {
        method: "POST",
        body: JSON.stringify({
          ...data,
          businessId,
          date: data.date ? new Date(`${format(data.date, 'yyyy-MM-dd')}T${data.time}:00`).toISOString() : null,
        }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Booking Submitted!",
        description: "We'll contact you shortly to confirm your appointment.",
      });
      setFormData({
        name: "",
        email: "",
        phone: "",
        date: null,
        time: "",
        serviceId: "",
        comments: "",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.phone || !formData.date || !formData.time) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    createBookingMutation.mutate(formData);
  };

  const timeSlots = [
    "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
    "12:00", "12:30", "13:00", "13:30", "14:00", "14:30",
    "15:00", "15:30", "16:00", "16:30", "17:00"
  ];

  if (!businessId) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-8 text-center">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Invalid Booking Link</h2>
            <p className="text-gray-600">This booking link appears to be invalid or expired.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-100">
      {/* Header with business image background */}
      <div 
        className="relative h-48 bg-gradient-to-r from-blue-600 to-blue-800 flex items-center justify-center"
        style={{
          backgroundImage: 'linear-gradient(rgba(37, 99, 235, 0.8), rgba(29, 78, 216, 0.8)), url("data:image/svg+xml,%3Csvg width="100" height="100" xmlns="http://www.w3.org/2000/svg"%3E%3Cdefs%3E%3Cpattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse"%3E%3Cpath d="M 20 0 L 0 0 0 20" fill="none" stroke="%23ffffff" stroke-width="0.5" opacity="0.1"/%3E%3C/pattern%3E%3C/defs%3E%3Crect width="100%" height="100%" fill="url(%23grid)"/%3E%3C/svg%3E")'
        }}
      >
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-2">Appointment Form</h1>
          {business && (
            <p className="text-blue-100 text-lg">{business.name}</p>
          )}
        </div>
      </div>

      {/* Form Container */}
      <div className="max-w-2xl mx-auto px-6 -mt-16 relative z-10">
        <Card className="bg-white shadow-xl border-0">
          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name Field */}
              <div className="space-y-2">
                <Label htmlFor="name" className="text-gray-700 font-medium">
                  Name <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full h-12 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              {/* Email Field */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-700 font-medium">
                  Email <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full h-12 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              {/* Phone Field */}
              <div className="space-y-2">
                <Label htmlFor="phone" className="text-gray-700 font-medium">
                  Phone number <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="(___) ___-____"
                  className="w-full h-12 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              {/* Service Selection */}
              {services.length > 0 && (
                <div className="space-y-2">
                  <Label className="text-gray-700 font-medium">Service</Label>
                  <Select value={formData.serviceId} onValueChange={(value) => setFormData({ ...formData, serviceId: value })}>
                    <SelectTrigger className="w-full h-12 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                      <SelectValue placeholder="Select a service" />
                    </SelectTrigger>
                    <SelectContent>
                      {services.map((service: any) => (
                        <SelectItem key={service.id} value={service.id}>
                          {service.name} - R{service.price}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Date and Time Row */}
              <div className="grid md:grid-cols-2 gap-6">
                {/* Date Field */}
                <div className="space-y-2">
                  <Label className="text-gray-700 font-medium">
                    Choose date <span className="text-red-500">*</span>
                  </Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full h-12 justify-start text-left font-normal border-gray-300 rounded-lg hover:bg-gray-50"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.date ? format(formData.date, "MM/dd/yyyy") : "mm/dd/yyyy"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={formData.date || undefined}
                        onSelect={(date) => setFormData({ ...formData, date: date || null })}
                        disabled={(date) => date < new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                {/* Time Field */}
                <div className="space-y-2">
                  <Label className="text-gray-700 font-medium">
                    Choose time <span className="text-red-500">*</span>
                  </Label>
                  <Select value={formData.time} onValueChange={(value) => setFormData({ ...formData, time: value })}>
                    <SelectTrigger className="w-full h-12 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                      <SelectValue placeholder="Select time" />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map((time) => (
                        <SelectItem key={time} value={time}>
                          {time}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Comments Field */}
              <div className="space-y-2">
                <Label htmlFor="comments" className="text-gray-700 font-medium">
                  Comments <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  id="comments"
                  value={formData.comments}
                  onChange={(e) => setFormData({ ...formData, comments: e.target.value })}
                  className="w-full min-h-[120px] border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  placeholder="Additional information or special requests..."
                />
              </div>

              {/* Submit Button */}
              <div className="pt-4">
                <Button
                  type="submit"
                  disabled={createBookingMutation.isPending}
                  className="w-full md:w-auto px-12 py-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-lg transition-all duration-200 hover:shadow-xl"
                >
                  {createBookingMutation.isPending ? "Submitting..." : "Submit"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center py-8">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <img 
              src="/attached_assets/Bookin logo_1754050974735.png" 
              alt="BOOKin Logo" 
              className="w-6 h-6 object-contain"
            />
            <span className="font-semibold text-blue-600">BOOKin</span>
          </div>
          <p className="text-gray-500 text-sm">Powered by BOOKin</p>
        </div>
      </div>
    </div>
  );
}