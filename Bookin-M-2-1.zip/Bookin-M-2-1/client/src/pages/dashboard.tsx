import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useWebSocket } from "@/hooks/useWebSocket";
import type { User } from "@shared/schema";
import { Home, Calendar, Users, Briefcase, QrCode, CreditCard, Bell, LogOut, Settings as SettingsIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

import DashboardHome from "@/components/dashboard/home";
import Bookings from "@/components/dashboard/bookings";
import Clients from "@/components/dashboard/clients";
import Services from "@/components/dashboard/services";
import QRCodeManagement from "@/components/dashboard/qr-dual";
import BusinessSettings from "@/components/dashboard/settings";
import Billing from "@/components/dashboard/billing";

import BookinLogo from "@assets/Bookin_logo_1765617562166.png";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("home");

  const { data: user } = useQuery<User>({
    queryKey: ["/api/auth/user"],
  });

  const { data: business } = useQuery<{ id: string }>({
    queryKey: ["/api/business"],
  });

  // Setup WebSocket for real-time updates
  useWebSocket(business?.id || "", user?.id || "");

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const sidebarItems = [
    { id: "home", label: "Dashboard", icon: Home },
    { id: "bookings", label: "Bookings", icon: Calendar },
    { id: "clients", label: "Clients", icon: Users },
    { id: "services", label: "Services", icon: Briefcase },
    { id: "qr", label: "QR Code", icon: QrCode },
    { id: "billing", label: "Billing", icon: CreditCard },
    { id: "settings", label: "Settings", icon: SettingsIcon },
  ];

  const getPageTitle = () => {
    const titles = {
      home: "Dashboard",
      bookings: "Bookings",
      clients: "Clients", 
      services: "Services",
      qr: "QR Code",
      billing: "Billing & Subscription",
      settings: "Settings",
    };
    return titles[activeTab as keyof typeof titles] || "Dashboard";
  };

  const renderContent = () => {
    switch (activeTab) {
      case "home":
        return <DashboardHome />;
      case "bookings":
        return <Bookings />;
      case "clients":
        return <Clients />;
      case "services":
        return <Services />;
      case "qr":
        return <QRCodeManagement />;
      case "billing":
        return <Billing />;
      case "settings":
        return <BusinessSettings />;
      default:
        return <DashboardHome />;
    }
  };

  return (
    <div className="flex h-screen bg-white">
      {/* Sidebar */}
      <div className="w-64 bg-gray-50 border-r border-gray-200 relative">
        <div className="p-6">
          {/* Logo */}
          <div className="flex items-center mb-8">
            <img src={BookinLogo} alt="BookIn" className="h-10" />
          </div>

          {/* Navigation */}
          <nav className="space-y-2">
            {sidebarItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                data-testid={`nav-${item.id}`}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-all duration-200 ${
                  activeTab === item.id
                    ? "bg-black text-white font-semibold"
                    : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="absolute bottom-6 left-6 right-6">
          <button
            onClick={handleLogout}
            data-testid="button-logout"
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left hover:bg-gray-100 transition-all text-gray-600 hover:text-gray-900"
          >
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </div>
      {/* Main Content */}
      <div className="flex-1 flex flex-col bg-gray-50">
        {/* Top Bar */}
        <div className="bg-white border-b border-gray-200 p-6">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold font-['Poppins'] text-gray-900">{getPageTitle()}</h1>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="w-6 h-6 text-gray-500 hover:text-gray-900 transition-colors" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-black rounded-full"></div>
              </Button>
              <div className="flex items-center space-x-3">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={user?.profileImageUrl || ""} />
                  <AvatarFallback className="bg-black text-white font-bold">
                    {user?.firstName?.[0]}{user?.lastName?.[0]}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium text-gray-900">
                  {user?.firstName} {user?.lastName}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Page Content */}
        <div className="flex-1 overflow-auto p-6">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}