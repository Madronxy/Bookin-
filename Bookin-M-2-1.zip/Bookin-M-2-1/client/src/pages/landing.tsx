import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { QrCode, MessageSquare, Calendar, Users, BarChart3, Shield, ArrowRight, Check, Star } from "lucide-react";

// Import logo and generated images
import BookinLogo from "@assets/Bookin_logo_1765617562166.png";
import heroImage from "@/assets/images/Professional_booking_appointment_tablet_3bbaabd2.png";
import dashboardImage from "@/assets/images/Business_dashboard_analytics_screen_1f32b7c9.png";
import qrScannerImage from "@/assets/images/QR_code_booking_scanner_7c7e090f.png";
import managementImage from "@/assets/images/Appointment_management_tablet_interface_6c204b5a.png";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-100 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <img src={BookinLogo} alt="BookIn" className="h-8" />
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-600 hover:text-gray-900 transition-colors">Features</a>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900 transition-colors">Pricing</a>
              <a href="#reviews" className="text-gray-600 hover:text-gray-900 transition-colors">Reviews</a>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={handleLogin} className="text-gray-600 hover:text-gray-900">
                Sign In
              </Button>
              <Button onClick={handleLogin} className="btn-primary px-6 py-2">
                Get Started
              </Button>
            </div>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 lg:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center space-x-2 bg-gray-100 px-3 py-1 rounded-full text-sm text-gray-600 mb-6">
                <Star className="w-4 h-4" />
                <span>AI-Powered Booking System</span>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight mb-6">
                Smart Booking<br />
                Made Simple
              </h1>
              <p className="text-lg text-gray-600 mb-8 max-w-lg">
                Transform your business with BOOKin's intelligent booking system. QR codes, WhatsApp integration, and powerful analytics - all in one platform.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button onClick={handleLogin} className="btn-primary px-6 py-3 text-base">
                  Start Free Trial
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
                <Button variant="outline" className="btn-secondary px-6 py-3 text-base">
                  Watch Demo
                </Button>
              </div>
              <div className="flex items-center space-x-6 text-sm text-gray-500">
                <div className="flex items-center space-x-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <span className="font-medium">4.9/5 rating</span>
                </div>
                <span>Trusted by 1000+ businesses</span>
              </div>
            </div>
            <div className="lg:order-first">
              <div className="relative rounded-xl overflow-hidden shadow-2xl">
                <img 
                  src={heroImage} 
                  alt="Professional using tablet for appointment booking"
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Everything you need to manage bookings
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Powerful features designed to streamline your booking process and grow your business
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* QR Code Booking */}
            <Card className="card-clean p-6">
              <CardContent className="p-0">
                <div className="feature-icon">
                  <QrCode className="w-6 h-6 text-gray-700" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">QR Code Booking</h3>
                <p className="text-gray-600">Generate unique QR codes for instant booking access. Perfect for physical locations.</p>
              </CardContent>
            </Card>

            {/* WhatsApp Integration */}
            <Card className="card-clean p-6">
              <CardContent className="p-0">
                <div className="feature-icon">
                  <MessageSquare className="w-6 h-6 text-gray-700" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">WhatsApp Integration</h3>
                <p className="text-gray-600">Automated confirmations, reminders, and customer communication via WhatsApp.</p>
              </CardContent>
            </Card>

            {/* Smart Calendar */}
            <Card className="card-clean p-6">
              <CardContent className="p-0">
                <div className="feature-icon">
                  <Calendar className="w-6 h-6 text-gray-700" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Smart Calendar</h3>
                <p className="text-gray-600">Intelligent scheduling with conflict detection and availability management.</p>
              </CardContent>
            </Card>

            {/* Client Management */}
            <Card className="card-clean p-6">
              <CardContent className="p-0">
                <div className="feature-icon">
                  <Users className="w-6 h-6 text-gray-700" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Client Management</h3>
                <p className="text-gray-600">Complete CRM with client history, preferences, and automated follow-ups.</p>
              </CardContent>
            </Card>

            {/* Analytics Dashboard */}
            <Card className="card-clean p-6">
              <CardContent className="p-0">
                <div className="feature-icon">
                  <BarChart3 className="w-6 h-6 text-gray-700" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Analytics Dashboard</h3>
                <p className="text-gray-600">Real-time insights into bookings, revenue, and business performance.</p>
              </CardContent>
            </Card>

            {/* Secure & Reliable */}
            <Card className="card-clean p-6">
              <CardContent className="p-0">
                <div className="feature-icon">
                  <Shield className="w-6 h-6 text-gray-700" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Secure & Reliable</h3>
                <p className="text-gray-600">Enterprise-grade security with 99.9% uptime guarantee.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              How BOOKin Works
            </h2>
            <p className="text-lg text-gray-600">
              Get started in minutes, not hours
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="text-center">
              <div className="relative mb-8">
                <div className="w-48 h-32 rounded-lg mx-auto overflow-hidden shadow-lg relative">
                  <img 
                    src={dashboardImage} 
                    alt="Business dashboard setup"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2">
                    <div className="w-6 h-6 bg-black rounded-full text-white flex items-center justify-center text-xs font-bold">1</div>
                  </div>
                </div>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Set Up Your Business</h3>
              <p className="text-gray-600">Add your services, staff, and availability in minutes</p>
            </div>

            {/* Step 2 */}
            <div className="text-center">
              <div className="relative mb-8">
                <div className="w-48 h-32 rounded-lg mx-auto overflow-hidden shadow-lg relative">
                  <img 
                    src={qrScannerImage} 
                    alt="QR code scanning for bookings"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2">
                    <div className="w-6 h-6 bg-black rounded-full text-white flex items-center justify-center text-xs font-bold">2</div>
                  </div>
                </div>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Share Your QR Code</h3>
              <p className="text-gray-600">Display your unique QR code for instant bookings</p>
            </div>

            {/* Step 3 */}
            <div className="text-center">
              <div className="relative mb-8">
                <div className="w-48 h-32 rounded-lg mx-auto overflow-hidden shadow-lg relative">
                  <img 
                    src={managementImage} 
                    alt="Managing appointments and growth"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2">
                    <div className="w-6 h-6 bg-black rounded-full text-white flex items-center justify-center text-xs font-bold">3</div>
                  </div>
                </div>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Manage & Grow</h3>
              <p className="text-gray-600">Track bookings, communicate with clients, and scale your business</p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Simple, Transparent Pricing
            </h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {/* Free Plan */}
            <Card className="card-clean p-8">
              <CardContent className="p-0">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Free</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-gray-900">R0</span>
                  <span className="text-gray-600 ml-1">/forever</span>
                </div>
                <p className="text-gray-600 mb-6">Perfect for getting started</p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    1 staff member
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    100 bookings per month
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    Basic QR code
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    Client CRM
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    Email support
                  </li>
                </ul>
                <Button onClick={handleLogin} className="w-full btn-secondary">
                  Get Started
                </Button>
              </CardContent>
            </Card>

            {/* Starter Plan */}
            <Card className="card-clean p-8 border-2 border-black relative">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <div className="bg-black text-white px-3 py-1 rounded-full text-sm font-medium">
                  Most Popular
                </div>
              </div>
              <CardContent className="p-0">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Starter</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-gray-900">R99</span>
                  <span className="text-gray-600 ml-1">/per month</span>
                </div>
                <p className="text-gray-600 mb-6">Great for small businesses</p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    10 staff members
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    Unlimited bookings
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    WhatsApp integration
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    Client CRM
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    Priority support
                  </li>
                </ul>
                <Button onClick={handleLogin} className="w-full btn-primary">
                  Get Started
                </Button>
              </CardContent>
            </Card>

            {/* Pro Plan */}
            <Card className="card-clean p-8">
              <CardContent className="p-0">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Pro</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-gray-900">R249</span>
                  <span className="text-gray-600 ml-1">/per month</span>
                </div>
                <p className="text-gray-600 mb-6">For growing businesses</p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    Unlimited staff
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    Unlimited bookings
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    Advanced analytics
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    Custom branding
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                    24/7 support
                  </li>
                </ul>
                <Button onClick={handleLogin} className="w-full btn-secondary">
                  Get Started
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Ready to transform your booking process?
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            Join thousands of businesses already using BOOKin to streamline their operations
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button onClick={handleLogin} className="btn-primary px-8 py-3 text-base">
              Start Your Free Trial
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <Button variant="outline" className="btn-secondary px-8 py-3 text-base">
              Schedule a Demo
            </Button>
          </div>
          <div className="flex items-center justify-center space-x-8 text-sm text-gray-500">
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4 text-green-500" />
              <span>No credit card required</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4 text-green-500" />
              <span>Setup in 5 minutes</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <img src={BookinLogo} alt="BookIn" className="h-8" />
              </div>
              <p className="text-gray-600">Smart booking management for modern businesses.</p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Product</h4>
              <ul className="space-y-2 text-gray-600">
                <li><a href="#features" className="hover:text-gray-900 transition-colors">Features</a></li>
                <li><a href="#pricing" className="hover:text-gray-900 transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-gray-900 transition-colors">API</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Support</h4>
              <ul className="space-y-2 text-gray-600">
                <li><a href="#" className="hover:text-gray-900 transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-gray-900 transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-gray-900 transition-colors">Status</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Company</h4>
              <ul className="space-y-2 text-gray-600">
                <li><a href="#" className="hover:text-gray-900 transition-colors">About</a></li>
                <li><a href="#" className="hover:text-gray-900 transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-gray-900 transition-colors">Careers</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-100 mt-8 pt-8 text-center text-gray-500">
            <p>&copy; 2024 BOOKin. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}