import { useEffect, useRef, useState } from 'react';
import { toast } from './use-toast';
import { queryClient } from '@/lib/queryClient';

interface WebSocketMessage {
  type: string;
  [key: string]: any;
}

export function useWebSocket(businessId?: string, userId?: string) {
  const ws = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [connectionAttempts, setConnectionAttempts] = useState(0);
  const maxReconnectAttempts = 5;

  const connect = () => {
    if (ws.current?.readyState === WebSocket.OPEN) return;

    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      ws.current = new WebSocket(wsUrl);

      ws.current.onopen = () => {
        console.log('WebSocket connected');
        setIsConnected(true);
        setConnectionAttempts(0);

        // Small delay to ensure connection is ready, then authenticate
        setTimeout(() => {
          if (businessId && userId && ws.current?.readyState === WebSocket.OPEN) {
            ws.current.send(JSON.stringify({
              type: 'authenticate',
              businessId,
              userId
            }));
          }
        }, 100);
      };

      ws.current.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          handleMessage(message);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };

      ws.current.onclose = () => {
        console.log('WebSocket disconnected');
        setIsConnected(false);
        
        // Attempt to reconnect
        if (connectionAttempts < maxReconnectAttempts) {
          setTimeout(() => {
            setConnectionAttempts(prev => prev + 1);
            connect();
          }, Math.pow(2, connectionAttempts) * 1000); // Exponential backoff
        }
      };

      ws.current.onerror = (error) => {
        console.error('WebSocket error:', error);
        setIsConnected(false);
      };

    } catch (error) {
      console.error('Failed to create WebSocket connection:', error);
    }
  };

  const handleMessage = (message: WebSocketMessage) => {
    switch (message.type) {
      case 'connected':
        console.log('WebSocket connection established:', message.clientId);
        break;

      case 'authenticated':
        console.log('WebSocket authenticated for business:', message.businessId);
        break;

      case 'new_booking':
        // Show toast notification
        toast({
          title: "New Booking!",
          description: `${message.booking.client.name} just booked an appointment`,
        });

        // Invalidate relevant queries to refresh data
        queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
        queryClient.invalidateQueries({ queryKey: ["/api/analytics/stats"] });
        break;

      case 'booking_updated':
        toast({
          title: "Booking Updated",
          description: `Booking status changed to ${message.booking.status}`,
        });

        queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
        queryClient.invalidateQueries({ queryKey: ["/api/analytics/stats"] });
        break;

      case 'stats_updated':
        // Silently update stats without showing a toast
        queryClient.invalidateQueries({ queryKey: ["/api/analytics/stats"] });
        break;

      case 'pong':
        // Keep-alive response
        break;

      case 'error':
        console.error('WebSocket error message:', message.message);
        break;

      default:
        console.log('Unknown WebSocket message type:', message.type);
    }
  };

  useEffect(() => {
    connect();

    // Cleanup on unmount
    return () => {
      if (ws.current) {
        ws.current.close();
        ws.current = null;
      }
    };
  }, [businessId, userId]);

  // Keep-alive ping every 30 seconds
  useEffect(() => {
    if (!isConnected) return;

    const pingInterval = setInterval(() => {
      if (ws.current?.readyState === WebSocket.OPEN) {
        ws.current.send(JSON.stringify({ type: 'ping' }));
      }
    }, 30000);

    return () => clearInterval(pingInterval);
  }, [isConnected]);

  return {
    isConnected,
    connectionAttempts,
    reconnect: connect
  };
}