import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Save, RotateCcw } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Business } from "@shared/schema";

type DayOfWeek = 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday';

interface BusinessHours {
  [key: string]: {
    isOpen: boolean;
    openTime: string;
    closeTime: string;
  };
}

const days: { key: DayOfWeek; label: string }[] = [
  { key: 'monday', label: 'Monday' },
  { key: 'tuesday', label: 'Tuesday' },
  { key: 'wednesday', label: 'Wednesday' },
  { key: 'thursday', label: 'Thursday' },
  { key: 'friday', label: 'Friday' },
  { key: 'saturday', label: 'Saturday' },
  { key: 'sunday', label: 'Sunday' },
];

const timeSlots = [
  '06:00', '07:00', '08:00', '09:00', '10:00', '11:00',
  '12:00', '13:00', '14:00', '15:00', '16:00', '17:00',
  '18:00', '19:00', '20:00', '21:00', '22:00'
];

const presetSchedules = [
  {
    name: "Standard Business (9-5)",
    hours: {
      monday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      tuesday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      wednesday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      thursday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      friday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
      saturday: { isOpen: false, openTime: '09:00', closeTime: '17:00' },
      sunday: { isOpen: false, openTime: '09:00', closeTime: '17:00' },
    }
  },
  {
    name: "Salon/Spa (10-8)",
    hours: {
      monday: { isOpen: false, openTime: '10:00', closeTime: '20:00' },
      tuesday: { isOpen: true, openTime: '10:00', closeTime: '20:00' },
      wednesday: { isOpen: true, openTime: '10:00', closeTime: '20:00' },
      thursday: { isOpen: true, openTime: '10:00', closeTime: '20:00' },
      friday: { isOpen: true, openTime: '10:00', closeTime: '20:00' },
      saturday: { isOpen: true, openTime: '10:00', closeTime: '18:00' },
      sunday: { isOpen: true, openTime: '11:00', closeTime: '17:00' },
    }
  },
  {
    name: "Medical Practice",
    hours: {
      monday: { isOpen: true, openTime: '08:00', closeTime: '17:00' },
      tuesday: { isOpen: true, openTime: '08:00', closeTime: '17:00' },
      wednesday: { isOpen: true, openTime: '08:00', closeTime: '17:00' },
      thursday: { isOpen: true, openTime: '08:00', closeTime: '17:00' },
      friday: { isOpen: true, openTime: '08:00', closeTime: '16:00' },
      saturday: { isOpen: true, openTime: '08:00', closeTime: '12:00' },
      sunday: { isOpen: false, openTime: '08:00', closeTime: '17:00' },
    }
  },
  {
    name: "Restaurant",
    hours: {
      monday: { isOpen: false, openTime: '11:00', closeTime: '22:00' },
      tuesday: { isOpen: true, openTime: '11:00', closeTime: '22:00' },
      wednesday: { isOpen: true, openTime: '11:00', closeTime: '22:00' },
      thursday: { isOpen: true, openTime: '11:00', closeTime: '22:00' },
      friday: { isOpen: true, openTime: '11:00', closeTime: '23:00' },
      saturday: { isOpen: true, openTime: '11:00', closeTime: '23:00' },
      sunday: { isOpen: true, openTime: '12:00', closeTime: '21:00' },
    }
  },
  {
    name: "Always Open (24/7)",
    hours: {
      monday: { isOpen: true, openTime: '00:00', closeTime: '23:59' },
      tuesday: { isOpen: true, openTime: '00:00', closeTime: '23:59' },
      wednesday: { isOpen: true, openTime: '00:00', closeTime: '23:59' },
      thursday: { isOpen: true, openTime: '00:00', closeTime: '23:59' },
      friday: { isOpen: true, openTime: '00:00', closeTime: '23:59' },
      saturday: { isOpen: true, openTime: '00:00', closeTime: '23:59' },
      sunday: { isOpen: true, openTime: '00:00', closeTime: '23:59' },
    }
  }
];

export default function BusinessHours() {
  const [businessHours, setBusinessHours] = useState<BusinessHours>({});
  const [hasChanges, setHasChanges] = useState(false);

  const { data: business, isLoading } = useQuery<Business>({
    queryKey: ["/api/business"],
  });

  const updateBusinessMutation = useMutation({
    mutationFn: async (data: Partial<Business>) => {
      await apiRequest(`/api/business`, {
        method: "PATCH",
        body: data,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/business"] });
      setHasChanges(false);
      toast({
        title: "Business hours updated",
        description: "Your operating hours have been saved successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (business?.businessHours) {
      try {
        const parsed = typeof business.businessHours === 'string' 
          ? JSON.parse(business.businessHours) 
          : business.businessHours;
        setBusinessHours(parsed);
      } catch {
        // Initialize with default hours if parsing fails
        setBusinessHours(presetSchedules[0].hours);
      }
    } else {
      // Initialize with default business hours
      setBusinessHours(presetSchedules[0].hours);
    }
  }, [business]);

  const applyPreset = (preset: typeof presetSchedules[0]) => {
    setBusinessHours(preset.hours);
    setHasChanges(true);
  };

  const toggleDay = (day: DayOfWeek) => {
    setBusinessHours(prev => ({
      ...prev,
      [day]: {
        ...prev[day],
        isOpen: !prev[day]?.isOpen
      }
    }));
    setHasChanges(true);
  };

  const updateTime = (day: DayOfWeek, field: 'openTime' | 'closeTime', value: string) => {
    setBusinessHours(prev => ({
      ...prev,
      [day]: {
        ...prev[day],
        [field]: value
      }
    }));
    setHasChanges(true);
  };

  const saveHours = () => {
    updateBusinessMutation.mutate({
      businessHours: JSON.stringify(businessHours),
    });
  };

  const resetChanges = () => {
    if (business?.businessHours) {
      try {
        const parsed = typeof business.businessHours === 'string' 
          ? JSON.parse(business.businessHours) 
          : business.businessHours;
        setBusinessHours(parsed);
      } catch {
        setBusinessHours(presetSchedules[0].hours);
      }
    } else {
      setBusinessHours(presetSchedules[0].hours);
    }
    setHasChanges(false);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="h-96 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Business Hours</h2>
          <p className="text-gray-500 mt-1">Set your operating hours for customer bookings</p>
        </div>
        <div className="flex gap-2">
          {hasChanges && (
            <Button
              onClick={resetChanges}
              variant="outline"
              className="btn-secondary"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset
            </Button>
          )}
          <Button
            onClick={saveHours}
            disabled={!hasChanges || updateBusinessMutation.isPending}
            className="btn-primary"
          >
            <Save className="w-4 h-4 mr-2" />
            {updateBusinessMutation.isPending ? "Saving..." : "Save Hours"}
          </Button>
        </div>
      </div>

      {/* Quick Preset Selection */}
      <Card className="card-clean">
        <CardHeader>
          <CardTitle className="text-gray-900 flex items-center">
            <Clock className="w-5 h-5 mr-2" />
            Quick Presets
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3">
            {presetSchedules.map((preset, index) => (
              <Button
                key={index}
                onClick={() => applyPreset(preset)}
                variant="outline"
                className="btn-secondary h-auto p-3 flex flex-col items-center space-y-1"
              >
                <span className="font-medium text-sm">{preset.name}</span>
                <span className="text-xs text-gray-500">
                  {Object.values(preset.hours).filter(h => h.isOpen).length} days/week
                </span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Days Configuration */}
      <Card className="card-clean">
        <CardHeader>
          <CardTitle className="text-gray-900">Weekly Schedule</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {days.map((day) => {
            const dayData = businessHours[day.key] || { isOpen: false, openTime: '09:00', closeTime: '17:00' };
            
            return (
              <div key={day.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200">
                <div className="flex items-center space-x-4">
                  <div className="w-24 text-gray-900 font-medium">
                    {day.label}
                  </div>
                  <Button
                    onClick={() => toggleDay(day.key)}
                    variant={dayData.isOpen ? "default" : "outline"}
                    size="sm"
                    className={dayData.isOpen 
                      ? "bg-black hover:bg-gray-800 text-white" 
                      : "border-gray-300 text-gray-500 hover:bg-gray-100"
                    }
                  >
                    {dayData.isOpen ? "Open" : "Closed"}
                  </Button>
                </div>

                {dayData.isOpen && (
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-gray-500 text-sm">From:</span>
                      <select
                        value={dayData.openTime}
                        onChange={(e) => updateTime(day.key, 'openTime', e.target.value)}
                        className="bg-white border border-gray-300 text-gray-900 text-sm rounded px-2 py-1 focus:ring-2 focus:ring-black focus:border-transparent"
                      >
                        {timeSlots.map(time => (
                          <option key={time} value={time}>{time}</option>
                        ))}
                      </select>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <span className="text-gray-500 text-sm">To:</span>
                      <select
                        value={dayData.closeTime}
                        onChange={(e) => updateTime(day.key, 'closeTime', e.target.value)}
                        className="bg-white border border-gray-300 text-gray-900 text-sm rounded px-2 py-1 focus:ring-2 focus:ring-black focus:border-transparent"
                      >
                        {timeSlots.map(time => (
                          <option key={time} value={time}>{time}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Current Schedule Summary */}
      <Card className="card-clean">
        <CardHeader>
          <CardTitle className="text-gray-900">Schedule Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {days.map((day) => {
              const dayData = businessHours[day.key] || { isOpen: false, openTime: '09:00', closeTime: '17:00' };
              
              return (
                <div key={day.key} className="flex flex-col space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-900 font-medium">{day.label.slice(0, 3)}</span>
                    <Badge 
                      variant={dayData.isOpen ? "default" : "secondary"} 
                      className={dayData.isOpen 
                        ? "bg-green-100 text-green-700 border border-green-200" 
                        : "bg-gray-100 text-gray-500"
                      }
                    >
                      {dayData.isOpen ? "Open" : "Closed"}
                    </Badge>
                  </div>
                  {dayData.isOpen && (
                    <div className="text-sm text-gray-500">
                      {dayData.openTime} - {dayData.closeTime}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}