import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Copy, Share, Zap, Smartphone, Globe } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { generateQRCode } from "@/lib/qr-generator";

interface QRCodeProps {
  business?: any;
}

export default function QRCode({ business }: QRCodeProps) {
  const [qrCode, setQrCode] = useState<string>("");
  const { toast } = useToast();

  const businessName = business?.name || "Your Business";
  const bookingUrl = `https://book.bookin.co/${business?.id || 'demo-business'}`;

  useState(() => {
    const generateQR = async () => {
      try {
        const qrCodeDataUrl = await generateQRCode(bookingUrl);
        setQrCode(qrCodeDataUrl);
      } catch (error) {
        console.error("Failed to generate QR code:", error);
      }
    };
    generateQR();
  }, [bookingUrl]);

  const handleDownloadPNG = () => {
    if (qrCode) {
      const link = document.createElement('a');
      link.download = `${businessName}-qr-code.png`;
      link.href = qrCode;
      link.click();
      
      toast({
        title: "Success",
        description: "QR code downloaded successfully",
      });
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(bookingUrl);
      toast({
        title: "Success",
        description: "Booking link copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy link",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold font-['Poppins'] mb-4 text-gray-900">Your Business QR Code</h2>
        <p className="text-gray-500">Share this QR code with customers for instant bookings</p>
      </div>

      {/* QR Code Display */}
      <Card className="card-clean">
        <CardContent className="p-8 text-center">
          <div className="inline-block p-8 bg-gray-50 rounded-2xl mb-6 border border-gray-200">
            {qrCode ? (
              <img src={qrCode} alt="QR Code" className="w-48 h-48" />
            ) : (
              <div className="w-48 h-48 bg-gray-200 rounded-lg flex items-center justify-center">
                <span className="text-gray-500">Loading QR Code...</span>
              </div>
            )}
          </div>
          
          <h3 className="text-xl font-semibold font-['Poppins'] mb-2 text-gray-900">{businessName}</h3>
          <p className="text-gray-500 mb-6">{bookingUrl}</p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button onClick={handleDownloadPNG} className="btn-primary">
              <Download className="w-4 h-4 mr-2" />
              Download PNG
            </Button>
            <Button
              variant="outline"
              className="btn-secondary"
            >
              <Download className="w-4 h-4 mr-2" />
              Download PDF
            </Button>
            <Button
              onClick={handleCopyLink}
              variant="outline"
              className="btn-secondary"
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy Link
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Usage Tips */}
      <Card className="card-clean">
        <CardHeader>
          <CardTitle className="text-gray-900 flex items-center">
            <Zap className="w-5 h-5 mr-2" />
            Pro Tips
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-black rounded-full mx-auto mb-3 flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-semibold mb-2 text-gray-900">Counter Display</h4>
              <p className="text-sm text-gray-500">
                Print and place on your reception counter for walk-in customers to book their next appointment
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-black rounded-full mx-auto mb-3 flex items-center justify-center">
                <Smartphone className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-semibold mb-2 text-gray-900">WhatsApp Status</h4>
              <p className="text-sm text-gray-500">
                Share as your WhatsApp business status to reach existing customers and increase bookings
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-black rounded-full mx-auto mb-3 flex items-center justify-center">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-semibold mb-2 text-gray-900">Website Integration</h4>
              <p className="text-sm text-gray-500">
                Add to your website or social media profiles to enable seamless online bookings
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Usage Stats */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="card-clean">
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-blue-600 mb-2">127</div>
            <p className="text-sm text-gray-500">QR Code Scans</p>
            <p className="text-xs text-gray-400 mt-1">This month</p>
          </CardContent>
        </Card>
        
        <Card className="card-clean">
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-purple-600 mb-2">89</div>
            <p className="text-sm text-gray-500">Bookings via QR</p>
            <p className="text-xs text-gray-400 mt-1">This month</p>
          </CardContent>
        </Card>
        
        <Card className="card-clean">
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-green-600 mb-2">70%</div>
            <p className="text-sm text-gray-500">Conversion Rate</p>
            <p className="text-xs text-gray-400 mt-1">Scans to bookings</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
