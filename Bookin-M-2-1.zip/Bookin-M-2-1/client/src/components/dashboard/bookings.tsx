import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, User } from "lucide-react";

export default function Bookings() {
  const [view, setView] = useState<"calendar" | "list">("calendar");
  
  const { data: bookings, isLoading } = useQuery({
    queryKey: ["/api/bookings"],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-blue-100 text-blue-700 border border-blue-200 px-3 py-1 rounded-full text-xs font-medium";
      case "confirmed":
        return "bg-green-100 text-green-700 border border-green-200 px-3 py-1 rounded-full text-xs font-medium";
      case "pending":
        return "bg-yellow-100 text-yellow-700 border border-yellow-200 px-3 py-1 rounded-full text-xs font-medium";
      case "cancelled":
      case "no_show":
        return "bg-red-100 text-red-700 border border-red-200 px-3 py-1 rounded-full text-xs font-medium";
      default:
        return "bg-gray-100 text-gray-700 border border-gray-200 px-3 py-1 rounded-full text-xs font-medium";
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-12 bg-gray-200 rounded mb-6"></div>
          <div className="h-96 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex space-x-4">
          <Button
            onClick={() => setView("calendar")}
            className={view === "calendar" ? "btn-primary" : "btn-secondary"}
            variant={view === "calendar" ? "default" : "outline"}
            data-testid="button-calendar-view"
          >
            Calendar View
          </Button>
          <Button
            onClick={() => setView("list")}
            className={view === "list" ? "btn-primary" : "btn-secondary"}
            variant={view === "list" ? "default" : "outline"}
            data-testid="button-list-view"
          >
            List View
          </Button>
        </div>
        <Button className="btn-primary" data-testid="button-new-booking">
          + New Booking
        </Button>
      </div>

      {view === "calendar" ? (
        /* Calendar View */
        <Card className="card-clean">
          <CardContent className="p-6">
            <div className="grid grid-cols-7 gap-4 mb-4">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                <div key={day} className="text-center font-semibold text-gray-600 py-2">
                  {day}
                </div>
              ))}
            </div>
            
            <div className="grid grid-cols-7 gap-4">
              {Array.from({ length: 35 }, (_, i) => {
                const date = new Date();
                date.setDate(date.getDate() - date.getDay() + i);
                const dayBookings = (bookings || []).filter((booking: any) => 
                  new Date(booking.date).toDateString() === date.toDateString()
                );

                return (
                  <div
                    key={i}
                    className={`text-center p-4 rounded-lg cursor-pointer transition-all min-h-[100px] ${
                      dayBookings.length > 0
                        ? "bg-gray-100 border-2 border-black"
                        : "hover:bg-gray-50 border border-gray-200"
                    }`}
                  >
                    <div className="font-bold text-gray-900">{date.getDate()}</div>
                    <div className="space-y-1 mt-2">
                      {dayBookings.slice(0, 2).map((booking: any) => (
                        <div
                          key={booking.id}
                          className="bg-black text-white px-2 py-1 rounded text-xs"
                        >
                          {booking.client?.name}
                        </div>
                      ))}
                      {dayBookings.length > 2 && (
                        <div className="text-xs text-gray-500">
                          +{dayBookings.length - 2} more
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      ) : (
        /* List View */
        <Card className="card-clean">
          <CardHeader>
            <CardTitle className="text-lg font-semibold font-['Poppins'] text-gray-900">All Bookings</CardTitle>
          </CardHeader>
          <CardContent>
            {!bookings || bookings.length === 0 ? (
              <div className="text-center py-12">
                <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 mb-4">No bookings yet</p>
                <Button className="btn-primary">Create First Booking</Button>
              </div>
            ) : (
              <div className="space-y-4">
                {bookings.map((booking: any) => (
                  <div key={booking.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center">
                        <User className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{booking.client?.name}</p>
                        <p className="text-sm text-gray-500">
                          {booking.service?.name} • {new Date(booking.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className={getStatusColor(booking.status)}>
                        {booking.status}
                      </span>
                      <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900">
                        Edit
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}