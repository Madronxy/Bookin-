import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, Users, TrendingUp } from "lucide-react";

export default function DashboardHome() {
  const { data: stats, isLoading } = useQuery<{
    todayBookings: number;
    upcomingBookings: number;
    activeClients: number;
    totalRevenue: number;
  }>({
    queryKey: ["/api/analytics/stats"],
  });

  const { data: bookings = [] } = useQuery<any[]>({
    queryKey: ["/api/bookings"],
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="card-clean">
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="w-16 h-16 bg-gray-200 rounded-full mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="card-clean">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold font-['Poppins'] text-gray-900">Today's Bookings</h3>
              <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center">
                <Calendar className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900">
              {stats?.todayBookings || 0}
            </div>
            <p className="text-sm text-gray-500">+15% from yesterday</p>
          </CardContent>
        </Card>

        <Card className="card-clean">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold font-['Poppins'] text-gray-900">Upcoming</h3>
              <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center">
                <Clock className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900">
              {stats?.upcomingBookings || 0}
            </div>
            <p className="text-sm text-gray-500">Next 24 hours</p>
          </CardContent>
        </Card>

        <Card className="card-clean">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold font-['Poppins'] text-gray-900">Active Clients</h3>
              <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center">
                <Users className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900">
              {stats?.activeClients || 0}
            </div>
            <p className="text-sm text-gray-500">+8% this month</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Bookings */}
      <Card className="card-clean">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold font-['Poppins'] text-gray-900">Recent Bookings</CardTitle>
            <Button variant="ghost" className="text-gray-600 hover:text-gray-900">
              View all
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {bookings.length === 0 ? (
            <div className="text-center py-12">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 mb-4">No bookings yet</p>
              <Button className="btn-primary">Create First Booking</Button>
            </div>
          ) : (
            <div className="space-y-4">
              {bookings.slice(0, 5).map((booking, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center">
                      <Users className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{booking.client?.name}</p>
                      <p className="text-sm text-gray-500">
                        {booking.service?.name} • {new Date(booking.date).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      booking.status === 'confirmed' ? 'bg-green-100 text-green-700 border border-green-200' :
                      booking.status === 'pending' ? 'bg-yellow-100 text-yellow-700 border border-yellow-200' :
                      booking.status === 'completed' ? 'bg-blue-100 text-blue-700 border border-blue-200' :
                      'bg-red-100 text-red-700 border border-red-200'
                    }`}>
                      {booking.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}