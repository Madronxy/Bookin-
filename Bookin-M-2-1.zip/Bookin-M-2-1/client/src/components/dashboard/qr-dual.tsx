import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { QrCode, Download, Copy, Calendar, MessageSquare, Save } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { generateQRCodeDataURL, generateBookingQR, generateWhatsAppQR, downloadQRCode } from "@/lib/qr-generator";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Business } from "@shared/schema";

const whatsappSchema = z.object({
  whatsappNumber: z.string().min(1, "WhatsApp number is required"),
});

type WhatsAppForm = z.infer<typeof whatsappSchema>;

export default function QRCodeManagement() {
  const [bookingQRPreview, setBookingQRPreview] = useState<string>("");
  const [whatsappQRPreview, setWhatsappQRPreview] = useState<string>("");
  const [showPreviews, setShowPreviews] = useState(true);

  const { data: business, isLoading } = useQuery<Business>({
    queryKey: ["/api/business"],
  });

  const form = useForm<WhatsAppForm>({
    resolver: zodResolver(whatsappSchema),
    defaultValues: {
      whatsappNumber: business?.whatsappNumber || "",
    },
  });

  useEffect(() => {
    form.reset({
      whatsappNumber: business?.whatsappNumber || "",
    });
  }, [business, form]);

  const updateBusinessMutation = useMutation({
    mutationFn: async (data: Partial<Business>) => {
      await apiRequest(`/api/business`, {
        method: "PATCH",
        body: data,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/business"] });
      toast({
        title: "Settings updated",
        description: "WhatsApp number saved successfully.",
      });
      generatePreviews();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const generatePreviews = async () => {
    if (!business?.id) return;

    try {
      // Generate booking QR preview
      const bookingUrl = generateBookingQR(business.id);
      const bookingQRData = await generateQRCodeDataURL(bookingUrl);
      setBookingQRPreview(bookingQRData);

      // Generate WhatsApp QR preview if number exists
      if (business.whatsappNumber) {
        const whatsappUrl = generateWhatsAppQR(business.whatsappNumber, business.name);
        const whatsappQRData = await generateQRCodeDataURL(whatsappUrl);
        setWhatsappQRPreview(whatsappQRData);
      }
    } catch (error) {
      console.error("Error generating QR previews:", error);
      toast({
        title: "Error",
        description: "Failed to generate QR code previews",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    if (business) {
      generatePreviews();
    }
  }, [business]);

  const onSubmit = (data: WhatsAppForm) => {
    updateBusinessMutation.mutate(data);
  };

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied",
        description: `${type} URL copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleDownloadBookingQR = async () => {
    if (!business?.id) return;
    try {
      const bookingUrl = generateBookingQR(business.id);
      await downloadQRCode(bookingUrl, `${business.name}-booking-qr.png`);
      toast({
        title: "Downloaded",
        description: `Booking QR code saved successfully`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to download QR code",
        variant: "destructive",
      });
    }
  };

  const handleDownloadWhatsAppQR = async () => {
    if (!business?.whatsappNumber) return;
    try {
      const whatsappUrl = generateWhatsAppQR(business.whatsappNumber, business.name);
      await downloadQRCode(whatsappUrl, `${business.name}-whatsapp-qr.png`);
      toast({
        title: "Downloaded",
        description: `WhatsApp QR code saved successfully`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to download QR code",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (!business) {
    return (
      <Card className="card-clean">
        <CardContent className="pt-6 text-center text-gray-500">
          <QrCode className="w-12 h-12 mx-auto mb-4 text-gray-400" />
          <p>Business information not found.</p>
        </CardContent>
      </Card>
    );
  }

  const bookingUrl = generateBookingQR(business.id);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">QR Code Management</h2>
        <p className="text-gray-500 mt-1">Generate and download QR codes for booking and WhatsApp</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Booking QR Code */}
        <Card className="bg-gradient-to-br from-blue-100 to-indigo-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-800 flex items-center">
              <Calendar className="w-5 h-5 mr-2" />
              Booking QR Code
            </CardTitle>
            <CardDescription className="text-blue-600">
              Customers scan this to access your booking form
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {bookingQRPreview && (
              <div className="bg-white p-4 rounded-lg border border-blue-200 shadow-sm">
                <img 
                  src={bookingQRPreview} 
                  alt="Booking QR Code" 
                  className="w-48 h-48 mx-auto"
                />
                <p className="text-center text-sm text-blue-600 mt-2 font-mono break-all">
                  {bookingUrl}
                </p>
              </div>
            )}
            
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row gap-2">
                <Button
                  onClick={handleDownloadBookingQR}
                  className="bg-blue-600 hover:bg-blue-700 text-white flex-1"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Booking QR
                </Button>
                <Button
                  onClick={() => copyToClipboard(bookingUrl, "Booking")}
                  variant="outline"
                  className="border-blue-300 text-blue-700 hover:bg-blue-50"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copy URL
                </Button>
              </div>
              
              <Badge variant="secondary" className="w-fit bg-blue-100 text-blue-800">
                Ready to use - No setup required
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* WhatsApp QR Code */}
        <Card className="bg-gradient-to-br from-green-100 to-emerald-50 border-green-200">
          <CardHeader>
            <CardTitle className="text-green-800 flex items-center">
              <MessageSquare className="w-5 h-5 mr-2" />
              WhatsApp QR Code
            </CardTitle>
            <CardDescription className="text-green-600">
              Customers scan this to start a WhatsApp conversation
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="whatsappNumber" className="text-green-700 font-medium">
                  WhatsApp Number
                </Label>
                <Input
                  {...form.register("whatsappNumber")}
                  placeholder="+27123456789"
                  className="border-green-300 focus:ring-green-500 focus:border-green-500"
                />
                {form.formState.errors.whatsappNumber && (
                  <p className="text-red-500 text-sm">{form.formState.errors.whatsappNumber.message}</p>
                )}
              </div>
              
              <Button
                type="submit"
                disabled={updateBusinessMutation.isPending}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                {updateBusinessMutation.isPending ? "Saving..." : "Save WhatsApp Number"}
              </Button>
            </form>

            {business.whatsappNumber && (
              <>
                {whatsappQRPreview && (
                  <div className="bg-white p-4 rounded-lg border border-green-200 shadow-sm">
                    <img 
                      src={whatsappQRPreview} 
                      alt="WhatsApp QR Code" 
                      className="w-48 h-48 mx-auto"
                    />
                    <p className="text-center text-sm text-green-600 mt-2">
                      <strong>Number:</strong> {business.whatsappNumber}
                    </p>
                  </div>
                )}
                
                <div className="space-y-3">
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Button
                      onClick={handleDownloadWhatsAppQR}
                      className="bg-green-600 hover:bg-green-700 text-white flex-1"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download WhatsApp QR
                    </Button>
                    <Button
                      onClick={() => copyToClipboard(generateWhatsAppQR(business.whatsappNumber || "", business.name), "WhatsApp")}
                      variant="outline"
                      className="border-green-300 text-green-700 hover:bg-green-50"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy URL
                    </Button>
                  </div>
                  
                  <Badge variant="secondary" className="w-fit bg-green-100 text-green-800">
                    <MessageSquare className="w-3 h-3 mr-1" />
                    Ready to scan
                  </Badge>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="card-clean">
        <CardHeader>
          <CardTitle className="text-gray-900">Usage Instructions</CardTitle>
        </CardHeader>
        <CardContent className="text-gray-600 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-blue-600 mb-2">Booking QR Code</h4>
              <ul className="space-y-1 text-sm">
                <li>• Print and display at your business location</li>
                <li>• Share on social media and marketing materials</li>
                <li>• Customers scan to access your booking form</li>
                <li>• Works instantly - no app required</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-green-600 mb-2">WhatsApp QR Code</h4>
              <ul className="space-y-1 text-sm">
                <li>• Opens WhatsApp chat with pre-filled message</li>
                <li>• Great for quick customer inquiries</li>
                <li>• Can be used for instant booking confirmations</li>
                <li>• Requires WhatsApp to be installed on device</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}