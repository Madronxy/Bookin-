import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Settings as SettingsIcon, MessageSquare, Webhook, QrCode, Save, ExternalLink, Copy } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Business } from "@shared/schema";

const businessSchema = z.object({
  name: z.string().min(1, "Business name is required"),
  email: z.string().email("Valid email is required").optional().or(z.literal("")),
  phone: z.string().min(1, "Phone number is required"),
  address: z.string().optional(),
  description: z.string().optional(),
  website: z.string().url("Valid website URL required").optional().or(z.literal("")),
});

const whatsappSchema = z.object({
  whatsappNumber: z.string().min(1, "WhatsApp number is required"),
  whatsappApiKey: z.string().optional(),
});

const webhookSchema = z.object({
  n8nWebhookUrl: z.string().url("Valid webhook URL required").optional().or(z.literal("")),
});

type BusinessForm = z.infer<typeof businessSchema>;
type WhatsAppForm = z.infer<typeof whatsappSchema>;
type WebhookForm = z.infer<typeof webhookSchema>;

export default function Settings() {
  const [activeTab, setActiveTab] = useState("business");

  const { data: business, isLoading } = useQuery<Business>({
    queryKey: ["/api/business"],
  });

  const businessForm = useForm<BusinessForm>({
    resolver: zodResolver(businessSchema),
    defaultValues: {
      name: business?.name || "",
      email: business?.email || "",
      phone: business?.phone || "",
      address: business?.address || "",
      description: business?.description || "",
      website: business?.website || "",
    },
  });

  const whatsappForm = useForm<WhatsAppForm>({
    resolver: zodResolver(whatsappSchema),
    defaultValues: {
      whatsappNumber: business?.whatsappNumber || "",
      whatsappApiKey: business?.whatsappApiKey || "",
    },
  });

  const webhookForm = useForm<WebhookForm>({
    resolver: zodResolver(webhookSchema),
    defaultValues: {
      n8nWebhookUrl: business?.n8nWebhookUrl || "",
    },
  });

  // Update forms when business data loads
  useState(() => {
    if (business) {
      businessForm.reset({
        name: business.name || "",
        email: business.email || "",
        phone: business.phone || "",
        address: business.address || "",
        description: business.description || "",
        website: business.website || "",
      });
      whatsappForm.reset({
        whatsappNumber: business.whatsappNumber || "",
        whatsappApiKey: business.whatsappApiKey || "",
      });
      webhookForm.reset({
        n8nWebhookUrl: business.n8nWebhookUrl || "",
      });
    }
  });

  const updateBusinessMutation = useMutation({
    mutationFn: async (data: Partial<Business>) => {
      await apiRequest(`/api/business`, {
        method: "PATCH",
        body: data,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/business"] });
      toast({
        title: "Settings updated",
        description: "Your business settings have been saved successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onBusinessSubmit = (data: BusinessForm) => {
    updateBusinessMutation.mutate(data);
  };

  const onWhatsAppSubmit = (data: WhatsAppForm) => {
    updateBusinessMutation.mutate(data);
  };

  const onWebhookSubmit = (data: WebhookForm) => {
    updateBusinessMutation.mutate(data);
  };

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied",
        description: `${type} copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return <div className="p-6">Loading settings...</div>;
  }

  const webhookEndpoint = `${window.location.origin}/api/webhooks/n8n/whatsapp-booking`;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <SettingsIcon className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-bold text-foreground">Settings</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="business">Business</TabsTrigger>
          <TabsTrigger value="whatsapp">WhatsApp</TabsTrigger>
          <TabsTrigger value="webhooks">N8N Integration</TabsTrigger>
          <TabsTrigger value="qr-codes">QR Codes</TabsTrigger>
        </TabsList>

        <TabsContent value="business">
          <Card>
            <CardHeader>
              <CardTitle>Business Information</CardTitle>
              <CardDescription>
                Update your business details and contact information
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={businessForm.handleSubmit(onBusinessSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Business Name *</Label>
                    <Input
                      id="name"
                      {...businessForm.register("name")}
                      placeholder="Your Business Name"
                    />
                    {businessForm.formState.errors.name && (
                      <p className="text-sm text-destructive">
                        {businessForm.formState.errors.name.message}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      {...businessForm.register("email")}
                      placeholder="business@example.com"
                    />
                    {businessForm.formState.errors.email && (
                      <p className="text-sm text-destructive">
                        {businessForm.formState.errors.email.message}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      {...businessForm.register("phone")}
                      placeholder="+27 11 123 4567"
                    />
                    {businessForm.formState.errors.phone && (
                      <p className="text-sm text-destructive">
                        {businessForm.formState.errors.phone.message}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="website">Website</Label>
                    <Input
                      id="website"
                      {...businessForm.register("website")}
                      placeholder="https://yourwebsite.com"
                    />
                    {businessForm.formState.errors.website && (
                      <p className="text-sm text-destructive">
                        {businessForm.formState.errors.website.message}
                      </p>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Textarea
                    id="address"
                    {...businessForm.register("address")}
                    placeholder="123 Business Street, City, 1234"
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    {...businessForm.register("description")}
                    placeholder="Tell customers about your business..."
                    rows={4}
                  />
                </div>

                <Button type="submit" disabled={updateBusinessMutation.isPending}>
                  <Save className="h-4 w-4 mr-2" />
                  {updateBusinessMutation.isPending ? "Saving..." : "Save Business Info"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="whatsapp">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                WhatsApp Integration
              </CardTitle>
              <CardDescription>
                Configure WhatsApp for booking notifications and customer communication
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={whatsappForm.handleSubmit(onWhatsAppSubmit)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="whatsappNumber">WhatsApp Business Number *</Label>
                  <Input
                    id="whatsappNumber"
                    {...whatsappForm.register("whatsappNumber")}
                    placeholder="+27611234567"
                  />
                  <p className="text-sm text-muted-foreground">
                    Include country code (e.g., +27 for South Africa)
                  </p>
                  {whatsappForm.formState.errors.whatsappNumber && (
                    <p className="text-sm text-destructive">
                      {whatsappForm.formState.errors.whatsappNumber.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="whatsappApiKey">WhatsApp API Key (Optional)</Label>
                  <Input
                    id="whatsappApiKey"
                    type="password"
                    {...whatsappForm.register("whatsappApiKey")}
                    placeholder="For advanced WhatsApp Business API features"
                  />
                  <p className="text-sm text-muted-foreground">
                    Only required for automated messaging features
                  </p>
                </div>

                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium text-sm mb-2">WhatsApp QR Code Features:</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Customers scan QR code to start WhatsApp chat</li>
                    <li>• Pre-filled booking message template</li>
                    <li>• Works with N8N agent for automated booking</li>
                    <li>• Real-time dashboard updates</li>
                  </ul>
                </div>

                <Button type="submit" disabled={updateBusinessMutation.isPending}>
                  <Save className="h-4 w-4 mr-2" />
                  {updateBusinessMutation.isPending ? "Saving..." : "Save WhatsApp Settings"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="webhooks">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Webhook className="h-5 w-5" />
                N8N Webhook Integration
              </CardTitle>
              <CardDescription>
                Configure N8N webhook integration for automated WhatsApp booking workflow
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>BOOKin Webhook Endpoint</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      value={webhookEndpoint}
                      readOnly
                      className="bg-muted"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(webhookEndpoint, "Webhook URL")}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Use this URL in your N8N workflow to send booking data to BOOKin
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Business ID</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      value={business?.id || ""}
                      readOnly
                      className="bg-muted"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(business?.id || "", "Business ID")}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Include this business_id in your N8N webhook payload
                  </p>
                </div>
              </div>

              <form onSubmit={webhookForm.handleSubmit(onWebhookSubmit)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="n8nWebhookUrl">N8N Webhook URL (Optional)</Label>
                  <Input
                    id="n8nWebhookUrl"
                    {...webhookForm.register("n8nWebhookUrl")}
                    placeholder="https://your-n8n-instance.com/webhook/..."
                  />
                  <p className="text-sm text-muted-foreground">
                    BOOKin will send booking confirmations to this N8N webhook
                  </p>
                </div>

                <Button type="submit" disabled={updateBusinessMutation.isPending}>
                  <Save className="h-4 w-4 mr-2" />
                  {updateBusinessMutation.isPending ? "Saving..." : "Save Webhook Settings"}
                </Button>
              </form>

              <div className="p-4 bg-muted rounded-lg">
                <h4 className="font-medium text-sm mb-2">N8N Integration Workflow:</h4>
                <ol className="text-sm text-muted-foreground space-y-1">
                  <li>1. Customer scans QR code → WhatsApp chat opens</li>
                  <li>2. N8N agent processes WhatsApp messages</li>
                  <li>3. Agent extracts booking details from conversation</li>
                  <li>4. N8N sends structured data to BOOKin webhook</li>
                  <li>5. New booking appears in dashboard in real-time</li>
                </ol>
                <div className="mt-3">
                  <Button variant="outline" size="sm" asChild>
                    <a href="/N8N_WHATSAPP_SETUP_INSTRUCTIONS.md" target="_blank">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View Setup Instructions
                    </a>
                  </Button>
                </div>
              </div>

              <div className="p-4 border border-amber-200 bg-amber-50 rounded-lg">
                <h4 className="font-medium text-sm text-amber-800 mb-2">Required JSON Payload Format:</h4>
                <pre className="text-xs text-amber-700 overflow-x-auto">
{`{
  "client_name": "John Doe",
  "client_phone": "+27611234567",
  "client_email": "john@example.com",
  "service_name": "Hair Cut",
  "booking_date": "2025-01-25",
  "booking_time": "14:30",
  "notes": "Customer notes",
  "source": "whatsapp",
  "business_id": "${business?.id || 'your-business-id'}"
}`}
                </pre>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="qr-codes">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <QrCode className="h-5 w-5" />
                QR Code Management
              </CardTitle>
              <CardDescription>
                Generate and manage QR codes for booking and WhatsApp integration
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">
                  QR Code management features are available in the main QR Codes section.
                </p>
                <Button variant="outline" asChild>
                  <a href="/dashboard?tab=qr-codes">
                    <QrCode className="h-4 w-4 mr-2" />
                    Go to QR Codes
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}