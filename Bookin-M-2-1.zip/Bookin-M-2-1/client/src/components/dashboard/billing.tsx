import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  CreditCard, 
  Calendar, 
  Users, 
  Zap, 
  CheckCircle, 
  XCircle,
  Crown,
  Star,
  ArrowUpRight
} from "lucide-react";
import SubscriptionPlans from "@/components/paystack/subscription-plans";

export default function Billing() {
  const [showPlans, setShowPlans] = useState(false);

  // Mock current subscription data - replace with real data
  const currentPlan = {
    name: "Free Plan",
    price: "R0",
    period: "month",
    status: "active",
    nextBilling: "N/A",
    features: {
      bookings: 10,
      clients: 50,
      staff: 1,
      analytics: false,
      whatsapp: false,
      customBranding: false
    }
  };

  if (showPlans) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Choose Your Plan</h2>
            <p className="text-gray-500">Upgrade to unlock more features for your business</p>
          </div>
          <Button 
            variant="outline" 
            onClick={() => setShowPlans(false)}
            className="btn-secondary"
          >
            Back to Billing
          </Button>
        </div>
        <SubscriptionPlans />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Billing & Subscription</h2>
          <p className="text-gray-500 mt-1">Manage your subscription and billing information</p>
        </div>
        <Button 
          onClick={() => setShowPlans(true)}
          className="btn-primary"
          data-testid="button-upgrade-plan"
        >
          <ArrowUpRight className="w-4 h-4 mr-2" />
          Upgrade Plan
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Current Plan Card */}
        <div className="lg:col-span-2">
          <Card className="card-clean">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-black flex items-center justify-center">
                    <Crown className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-gray-900 text-lg">{currentPlan.name}</CardTitle>
                    <CardDescription className="text-gray-500">
                      {currentPlan.price}/{currentPlan.period}
                    </CardDescription>
                  </div>
                </div>
                <Badge 
                  variant={currentPlan.status === 'active' ? 'default' : 'destructive'}
                  className={currentPlan.status === 'active' 
                    ? 'bg-green-100 text-green-700 border-green-200' 
                    : 'bg-red-100 text-red-700 border-red-200'
                  }
                >
                  {currentPlan.status === 'active' ? (
                    <CheckCircle className="w-3 h-3 mr-1" />
                  ) : (
                    <XCircle className="w-3 h-3 mr-1" />
                  )}
                  {currentPlan.status.charAt(0).toUpperCase() + currentPlan.status.slice(1)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Next billing date</p>
                  <p className="text-gray-900 font-medium">{currentPlan.nextBilling}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Payment method</p>
                  <div className="flex items-center space-x-2">
                    <CreditCard className="w-4 h-4 text-gray-500" />
                    <p className="text-gray-900 font-medium">Not configured</p>
                  </div>
                </div>
              </div>
              
              <Separator className="bg-gray-200" />
              
              {/* Plan Features */}
              <div>
                <h4 className="text-gray-900 font-medium mb-3">Current Plan Features</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-gray-700" />
                    <span className="text-gray-600 text-sm">{currentPlan.features.bookings} bookings/month</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-gray-700" />
                    <span className="text-gray-600 text-sm">{currentPlan.features.clients} clients</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Star className="w-4 h-4 text-gray-700" />
                    <span className="text-gray-600 text-sm">{currentPlan.features.staff} staff member</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {currentPlan.features.analytics ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <XCircle className="w-4 h-4 text-gray-400" />
                    )}
                    <span className={`text-sm ${currentPlan.features.analytics ? 'text-gray-600' : 'text-gray-400'}`}>
                      Advanced analytics
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {currentPlan.features.whatsapp ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <XCircle className="w-4 h-4 text-gray-400" />
                    )}
                    <span className={`text-sm ${currentPlan.features.whatsapp ? 'text-gray-600' : 'text-gray-400'}`}>
                      WhatsApp integration
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {currentPlan.features.customBranding ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <XCircle className="w-4 h-4 text-gray-400" />
                    )}
                    <span className={`text-sm ${currentPlan.features.customBranding ? 'text-gray-600' : 'text-gray-400'}`}>
                      Custom branding
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Usage Stats */}
        <div className="space-y-4">
          <Card className="card-clean">
            <CardHeader className="pb-3">
              <CardTitle className="text-gray-900 text-base">Usage This Month</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Bookings</span>
                  <span className="text-gray-900">3 / {currentPlan.features.bookings}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-black h-2 rounded-full" 
                    style={{ width: `${(3 / currentPlan.features.bookings) * 100}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Clients</span>
                  <span className="text-gray-900">12 / {currentPlan.features.clients}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-black h-2 rounded-full" 
                    style={{ width: `${(12 / currentPlan.features.clients) * 100}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Staff</span>
                  <span className="text-gray-900">1 / {currentPlan.features.staff}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-black h-2 rounded-full" 
                    style={{ width: `${(1 / currentPlan.features.staff) * 100}%` }}
                  ></div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="card-clean">
            <CardHeader className="pb-3">
              <CardTitle className="text-gray-900 text-base">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start btn-secondary"
                onClick={() => setShowPlans(true)}
              >
                <Zap className="w-4 h-4 mr-2" />
                View All Plans
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start btn-secondary"
                disabled
              >
                <CreditCard className="w-4 h-4 mr-2" />
                Payment Methods
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start btn-secondary"
                disabled
              >
                <Calendar className="w-4 h-4 mr-2" />
                Billing History
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Upgrade Prompt */}
      {currentPlan.name === "Free Plan" && (
        <Card className="card-clean border-2 border-black">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-full bg-black flex items-center justify-center">
                  <Crown className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-gray-900 font-semibold">Ready to grow your business?</h3>
                  <p className="text-gray-500 text-sm">Upgrade to Pro or Enterprise for unlimited bookings and advanced features.</p>
                </div>
              </div>
              <Button 
                onClick={() => setShowPlans(true)}
                className="btn-primary"
              >
                Upgrade Now
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}