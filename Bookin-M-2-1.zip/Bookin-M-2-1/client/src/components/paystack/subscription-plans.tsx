import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Star, CreditCard, Loader2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Business } from "@shared/schema";

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  currency: string;
  interval: string;
  features: string[];
  popular?: boolean;
  paystackPlanCode: string;
}

const plans: SubscriptionPlan[] = [
  {
    id: "free",
    name: "Free",
    price: 0,
    currency: "ZAR",
    interval: "month",
    features: [
      "Up to 50 bookings per month",
      "Basic QR codes",
      "Email notifications",
      "Basic analytics"
    ],
    paystackPlanCode: ""
  },
  {
    id: "starter",
    name: "Starter",
    price: 299,
    currency: "ZAR",
    interval: "month",
    features: [
      "Up to 200 bookings per month",
      "Custom QR codes",
      "WhatsApp integration",
      "Advanced analytics",
      "Priority support"
    ],
    paystackPlanCode: "PLN_starter_monthly",
    popular: true
  },
  {
    id: "professional",
    name: "Professional",
    price: 599,
    currency: "ZAR",
    interval: "month",
    features: [
      "Unlimited bookings",
      "Multiple staff accounts",
      "Advanced automation",
      "Custom branding",
      "API access",
      "24/7 support"
    ],
    paystackPlanCode: "PLN_professional_monthly"
  }
];

declare global {
  interface Window {
    PaystackPop?: {
      setup: (config: any) => {
        openIframe: () => void;
      };
    };
  }
}

export default function SubscriptionPlans() {
  const [isProcessing, setIsProcessing] = useState<string | null>(null);

  const { data: business } = useQuery<Business>({
    queryKey: ["/api/business"],
  });

  const updateSubscriptionMutation = useMutation({
    mutationFn: async (data: { plan: string; subscriptionId?: string }) => {
      return await apiRequest("/api/subscription/update", {
        method: "POST",
        body: data,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/business"] });
      toast({
        title: "Subscription Updated",
        description: "Your subscription has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Subscription Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const initializePaystackPayment = (plan: SubscriptionPlan) => {
    if (!business?.email) {
      toast({
        title: "Error",
        description: "Business email is required for subscription.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(plan.id);

    // Load Paystack script if not already loaded
    if (!window.PaystackPop) {
      const script = document.createElement('script');
      script.src = 'https://js.paystack.co/v1/inline.js';
      script.onload = () => processPayment(plan);
      document.head.appendChild(script);
    } else {
      processPayment(plan);
    }
  };

  const processPayment = (plan: SubscriptionPlan) => {
    if (!window.PaystackPop || !business) return;

    const handler = window.PaystackPop.setup({
      key: 'pk_test_your_paystack_public_key', // This will be replaced with actual Paystack public key
      email: business.email,
      amount: plan.price * 100, // Paystack expects amount in kobo (cents)
      currency: plan.currency,
      plan: plan.paystackPlanCode,
      metadata: {
        business_id: business.id,
        plan_id: plan.id,
        custom_fields: [
          {
            display_name: "Business Name",
            variable_name: "business_name",
            value: business.name
          }
        ]
      },
      callback: (response: any) => {
        // Payment successful
        updateSubscriptionMutation.mutate({
          plan: plan.id,
          subscriptionId: response.reference
        });
        setIsProcessing(null);
        
        toast({
          title: "Payment Successful",
          description: `Welcome to the ${plan.name} plan!`,
        });
      },
      onClose: () => {
        setIsProcessing(null);
        toast({
          title: "Payment Cancelled",
          description: "You can upgrade anytime from your dashboard.",
        });
      }
    });

    handler.openIframe();
  };

  const handleFreePlan = () => {
    updateSubscriptionMutation.mutate({ plan: "free" });
  };

  const getCurrentPlan = () => {
    return business?.subscriptionPlan || "free";
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-4">Choose Your Plan</h2>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Upgrade your business management with powerful features and automation.
          All plans include secure payment processing and 24/7 uptime.
        </p>
      </div>

      {/* Current Plan Badge */}
      {business && (
        <div className="text-center">
          <Badge variant="secondary" className="text-lg px-4 py-2">
            Current Plan: {plans.find(p => p.id === getCurrentPlan())?.name || "Free"}
          </Badge>
        </div>
      )}

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {plans.map((plan) => {
          const isCurrentPlan = getCurrentPlan() === plan.id;
          const isProcessingThis = isProcessing === plan.id;

          return (
            <Card 
              key={plan.id} 
              className={`relative bg-gray-800 border-gray-700 ${
                plan.popular ? 'ring-2 ring-neon-teal shadow-lg shadow-neon-teal/20' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-neon-teal text-black font-semibold px-4 py-1">
                    <Star className="w-4 h-4 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}

              <CardHeader className="text-center">
                <CardTitle className="text-2xl font-bold text-white">
                  {plan.name}
                </CardTitle>
                <CardDescription className="text-gray-400">
                  <span className="text-4xl font-bold text-white">
                    R{plan.price}
                  </span>
                  {plan.price > 0 && (
                    <span className="text-gray-400">/{plan.interval}</span>
                  )}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Features */}
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start text-gray-300">
                      <Check className="w-5 h-5 text-neon-teal mr-3 flex-shrink-0 mt-0.5" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* Action Button */}
                <div className="pt-4">
                  {isCurrentPlan ? (
                    <Button 
                      disabled 
                      className="w-full bg-gray-600 text-gray-300"
                    >
                      Current Plan
                    </Button>
                  ) : plan.id === "free" ? (
                    <Button
                      onClick={handleFreePlan}
                      disabled={updateSubscriptionMutation.isPending}
                      variant="outline"
                      className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      {updateSubscriptionMutation.isPending ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        "Switch to Free"
                      )}
                    </Button>
                  ) : (
                    <Button
                      onClick={() => initializePaystackPayment(plan)}
                      disabled={isProcessingThis || updateSubscriptionMutation.isPending}
                      className={`w-full ${
                        plan.popular 
                          ? 'bg-neon-teal text-black hover:bg-neon-teal/90' 
                          : 'bg-neon-purple text-white hover:bg-neon-purple/90'
                      }`}
                    >
                      {isProcessingThis ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <CreditCard className="w-4 h-4 mr-2" />
                      )}
                      {isProcessingThis ? "Processing..." : `Upgrade to ${plan.name}`}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Payment Security Notice */}
      <div className="text-center">
        <p className="text-sm text-gray-500 max-w-2xl mx-auto">
          🔒 All payments are processed securely through Paystack. 
          Your card details are never stored on our servers. 
          Cancel anytime from your dashboard.
        </p>
      </div>
    </div>
  );
}