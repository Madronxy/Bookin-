interface LogoProps {
  className?: string;
  showTagline?: boolean;
  variant?: 'full' | 'icon' | 'text';
}

export function Logo({ className = "", showTagline = true, variant = 'full' }: LogoProps) {
  const logoSvg = (
    <svg viewBox="0 0 400 180" className={`${className}`} xmlns="http://www.w3.org/2000/svg">
      {/* BOOKin Text */}
      <text x="20" y="120" className="fill-bookin-navy text-[80px] font-black font-sans">
        Book
      </text>
      <text x="260" y="120" className="fill-bookin-green text-[80px] font-black font-sans">
        In
      </text>
      
      {/* Green underline accent */}
      <rect x="260" y="130" width="120" height="8" className="fill-bookin-green" />
      
      {showTagline && (
        <text x="20" y="155" className="fill-bookin-navy text-[18px] font-medium">
          Seamless Appointment Booking
        </text>
      )}
    </svg>
  );

  if (variant === 'icon') {
    return (
      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br from-bookin-navy to-bookin-green flex items-center justify-center ${className}`}>
        <span className="text-white font-black text-lg">B</span>
      </div>
    );
  }

  if (variant === 'text') {
    return (
      <div className={`flex items-center space-x-1 ${className}`}>
        <span className="text-bookin-navy font-black text-2xl">Book</span>
        <span className="text-bookin-green font-black text-2xl">In</span>
      </div>
    );
  }

  return logoSvg;
}