import QRCode from 'qrcode';

interface QRCodeOptions {
  size?: number;
  margin?: number;
  backgroundColor?: string;
  foregroundColor?: string;
}

export async function generateQRCodeDataURL(
  text: string,
  options: QRCodeOptions = {}
): Promise<string> {
  const {
    size = 256,
    margin = 2,
    backgroundColor = '#ffffff',
    foregroundColor = '#000000'
  } = options;

  try {
    const qrCodeDataUrl = await QRCode.toDataURL(text, {
      width: size,
      margin: margin,
      color: {
        dark: foregroundColor,
        light: backgroundColor,
      },
      errorCorrectionLevel: 'M'
    });
    
    return qrCodeDataUrl;
  } catch (error) {
    throw new Error(`Failed to generate QR code: ${error}`);
  }
}

export function generateBookingQR(businessId: string): string {
  const baseUrl = window.location.origin;
  return `${baseUrl}/booking/${businessId}`;
}

export function generateWhatsAppQR(phoneNumber: string, businessName?: string): string {
  if (!phoneNumber) return "";
  
  // Clean phone number - remove all non-digits
  const cleanPhone = phoneNumber.replace(/\D/g, "");
  
  // Enhanced WhatsApp URL format with structured booking message for N8N agent
  const message = businessName ? 
    `Hi ${businessName}! I'd like to make a booking. My name is [YOUR_NAME] and I'm interested in [SERVICE_NAME]. I'm available on [PREFERRED_DATE] at [PREFERRED_TIME]. Please let me know what information you need.` : 
    "Hello, I'd like to book an appointment. My name is [YOUR_NAME] and I'm interested in [SERVICE_NAME]. I'm available on [PREFERRED_DATE] at [PREFERRED_TIME].";
  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
  
  return whatsappUrl;
}

export async function downloadQRCode(text: string, filename: string) {
  try {
    const dataUrl = await generateQRCodeDataURL(text, { size: 512 });
    const link = document.createElement("a");
    link.download = filename;
    link.href = dataUrl;
    link.click();
  } catch (error) {
    console.error('Error downloading QR code:', error);
    throw error;
  }
}